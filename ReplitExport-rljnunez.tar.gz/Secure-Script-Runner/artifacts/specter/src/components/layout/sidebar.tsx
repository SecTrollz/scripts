import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  FolderOpen,
  Binary,
  Cpu,
  ShieldAlert,
  Code2,
  Bot,
  Container,
  Zap,
  Activity,
  Circle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useGetDashboardStats } from "@workspace/api-client-react";

const NAV = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/projects", icon: FolderOpen, label: "Projects" },
  { path: "/binaries", icon: Binary, label: "Binary Analysis" },
  { path: "/firmware", icon: Cpu, label: "Firmware" },
  { path: "/vulnerabilities", icon: ShieldAlert, label: "Vulnerabilities" },
  { path: "/scripts", icon: Code2, label: "Ghidra Scripts" },
  { path: "/agent", icon: Bot, label: "AI Agent" },
  { path: "/docker", icon: Container, label: "Stack Manager" },
];

export function Sidebar() {
  const [location] = useLocation();
  const { data: stats } = useGetDashboardStats({ query: { refetchInterval: 10000 } });

  return (
    <aside className="w-52 shrink-0 flex flex-col border-r border-sidebar-border bg-sidebar h-screen sticky top-0 overflow-hidden">
      {/* Wordmark */}
      <div className="px-5 py-5 border-b border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded flex items-center justify-center bg-primary/15 border border-primary/30">
            <Zap className="w-3.5 h-3.5 text-primary" />
          </div>
          <div>
            <div className="text-[13px] font-semibold tracking-[0.18em] text-foreground">SPECTER</div>
            <div className="text-[9px] text-sidebar-muted-foreground tracking-widest uppercase mt-0.5">Rev. Eng. Platform</div>
          </div>
        </div>
      </div>

      {/* Service status pills */}
      <div className="px-4 py-2.5 border-b border-sidebar-border flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Circle
            className={cn("w-2 h-2 fill-current", stats?.ollamaOnline ? "text-[hsl(145_55%_50%)] pulse-dot" : "text-[hsl(0_0%_28%)]")}
          />
          <span className="text-[10px] text-sidebar-muted-foreground tracking-wider">OLLAMA</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Circle
            className={cn("w-2 h-2 fill-current", stats?.ghidraMcpOnline ? "text-[hsl(145_55%_50%)] pulse-dot" : "text-[hsl(0_0%_28%)]")}
          />
          <span className="text-[10px] text-sidebar-muted-foreground tracking-wider">GHIDRA</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Activity className="w-2.5 h-2.5 text-primary/70" />
          <span className="text-[10px] text-primary/80">{stats?.activeJobs ?? 0}</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 space-y-0.5">
        {NAV.map(({ path, icon: Icon, label }) => {
          const isActive = path === "/" ? location === "/" : location.startsWith(path);
          return (
            <Link key={path} href={path}>
              <div
                data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
                className={cn(
                  "flex items-center gap-2.5 pl-4 pr-3 py-2 text-[12.5px] font-medium cursor-pointer transition-all duration-100",
                  isActive ? "nav-active" : "nav-inactive"
                )}
              >
                <Icon
                  className={cn(
                    "w-3.5 h-3.5 shrink-0",
                    isActive ? "text-primary" : "text-[hsl(0_0%_42%)]"
                  )}
                />
                <span className="truncate">{label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Stats footer */}
      <div className="px-4 py-3 border-t border-sidebar-border space-y-1.5">
        <div className="flex justify-between text-[10px]">
          <span className="text-sidebar-muted-foreground">Projects</span>
          <span className="text-foreground/70">{stats?.totalProjects ?? 0}</span>
        </div>
        <div className="flex justify-between text-[10px]">
          <span className="text-sidebar-muted-foreground">Vulns</span>
          <span className={stats?.totalVulnerabilities ? "text-[hsl(4_85%_65%)]" : "text-foreground/70"}>
            {stats?.totalVulnerabilities ?? 0}
          </span>
        </div>
        <div className="flex justify-between text-[10px]">
          <span className="text-sidebar-muted-foreground">Critical</span>
          <span className={stats?.criticalVulnerabilities ? "text-[hsl(4_85%_65%)]" : "text-foreground/70"}>
            {stats?.criticalVulnerabilities ?? 0}
          </span>
        </div>
        <div className="pt-1.5 text-[9px] text-sidebar-muted-foreground/40 tracking-widest">v1.0.0-SPECTER</div>
      </div>
    </aside>
  );
}
