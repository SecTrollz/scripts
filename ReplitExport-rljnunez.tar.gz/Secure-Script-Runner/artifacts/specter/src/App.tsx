import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/layout/sidebar";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Projects from "@/pages/projects";
import Binaries from "@/pages/binaries";
import Firmware from "@/pages/firmware";
import Vulnerabilities from "@/pages/vulnerabilities";
import Scripts from "@/pages/scripts";
import Agent from "@/pages/agent";
import Docker from "@/pages/docker";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5000,
    },
  },
});

function AppLayout() {
  return (
    <div className="flex min-h-screen bg-background">
      <div className="scanline" />
      <Sidebar />
      <main className="flex-1 overflow-y-auto min-w-0">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/projects" component={Projects} />
          <Route path="/binaries" component={Binaries} />
          <Route path="/firmware" component={Firmware} />
          <Route path="/vulnerabilities" component={Vulnerabilities} />
          <Route path="/scripts" component={Scripts} />
          <Route path="/agent" component={Agent} />
          <Route path="/docker" component={Docker} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AppLayout />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
