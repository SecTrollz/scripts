import { useState } from "react";
import { useListProjects, useCreateProject, useDeleteProject, getListProjectsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { FolderOpen, Plus, Trash2, Binary, Cpu, ShieldAlert, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { formatDistanceToNow } from "date-fns";

const createSchema = z.object({
  name: z.string().min(1, "Name required"),
  description: z.string().optional(),
});
type CreateForm = z.infer<typeof createSchema>;

export default function Projects() {
  const { data: projects, isLoading } = useListProjects();
  const createProject = useCreateProject();
  const deleteProject = useDeleteProject();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);

  const form = useForm<CreateForm>({ resolver: zodResolver(createSchema), defaultValues: { name: "", description: "" } });

  const onSubmit = (data: CreateForm) => {
    createProject.mutate(
      { data },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListProjectsQueryKey() });
          toast({ title: "Project created", description: data.name });
          setOpen(false);
          form.reset();
        },
        onError: () => toast({ title: "Error", description: "Failed to create project", variant: "destructive" }),
      }
    );
  };

  const handleDelete = (id: string, name: string) => {
    if (!confirm(`Delete project "${name}"? This cannot be undone.`)) return;
    deleteProject.mutate(
      { id },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListProjectsQueryKey() });
          toast({ title: "Project deleted" });
        },
      }
    );
  };

  return (
    <div className="p-6 space-y-5 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] text-muted-foreground uppercase mb-1">Project Management</div>
          <h1 className="text-xl font-semibold text-foreground">Projects</h1>
        </div>
        <Button
          data-testid="button-create-project"
          size="sm"
          className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 text-[12px] font-medium"
          onClick={() => setOpen(true)}
        >
          <Plus className="w-3.5 h-3.5" /> New Project
        </Button>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-[12px]">Loading...</div>
      ) : !projects?.length ? (
        <div className="rounded-md border border-border bg-card p-12 text-center dot-bg">
          <FolderOpen className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <div className="text-[13px] text-muted-foreground">No projects yet</div>
          <div className="text-[11px] text-muted-foreground/60 mt-1">Create a project to organise binaries and firmware</div>
        </div>
      ) : (
        <div className="grid gap-3">
          {projects.map((p) => (
            <div
              key={p.id}
              data-testid={`card-project-${p.id}`}
              className="rounded border border-border bg-card px-5 py-4 flex items-center gap-4 hover:border-primary/30 hover:bg-primary/5 transition-all cursor-pointer group"
              onClick={() => setLocation(`/projects/${p.id}`)}
            >
              <FolderOpen className="w-5 h-5 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-bold text-foreground">{p.name}</div>
                {p.description && <div className="text-[11px] text-muted-foreground truncate mt-0.5">{p.description}</div>}
                <div className="text-[10px] text-muted-foreground mt-1">
                  {p.createdAt ? formatDistanceToNow(new Date(p.createdAt), { addSuffix: true }) : ""}
                </div>
              </div>
              <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Binary className="w-3 h-3 text-secondary" />
                  <span className="text-secondary">{p.binaryCount}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Cpu className="w-3 h-3 text-accent" />
                  <span className="text-accent">{p.firmwareCount}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldAlert className="w-3 h-3 text-destructive" />
                  <span className="text-destructive">{p.vulnerabilityCount}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  data-testid={`button-delete-project-${p.id}`}
                  onClick={(e) => { e.stopPropagation(); handleDelete(p.id, p.name); }}
                  className="p-1.5 rounded hover:bg-destructive/15 hover:text-destructive text-muted-foreground transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border text-foreground max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[13px] font-bold tracking-widest uppercase">New Project</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Project Name</Label>
              <Input
                data-testid="input-project-name"
                {...form.register("name")}
                className="mt-1 bg-input border-border text-foreground text-[12px]"
                placeholder="APT28_Sample_2024"
                autoFocus
              />
              {form.formState.errors.name && (
                <p className="text-[10px] text-destructive mt-1">{form.formState.errors.name.message}</p>
              )}
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Description</Label>
              <Textarea
                data-testid="input-project-description"
                {...form.register("description")}
                className="mt-1 bg-input border-border text-foreground text-[12px] resize-none"
                rows={3}
                placeholder="Analysis target, threat actor attribution, campaign notes..."
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" size="sm" onClick={() => setOpen(false)} className="text-[11px] uppercase tracking-wider border-border text-muted-foreground hover:text-foreground">
                Cancel
              </Button>
              <Button
                data-testid="button-submit-project"
                type="submit"
                size="sm"
                disabled={createProject.isPending}
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-[11px] uppercase tracking-wider"
              >
                {createProject.isPending ? "Creating..." : "Create Project"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
