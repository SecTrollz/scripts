import { useGetDashboardStats, useGetRecentActivity } from "@workspace/api-client-react";
import { Activity, Binary, Cpu, FolderOpen, ShieldAlert, Zap, Terminal, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

function StatCard({ label, value, sub, icon: Icon, color = "primary" }: { label: string; value: number | string; sub?: string; icon: React.ElementType; color?: "primary" | "destructive" | "accent" | "secondary" }) {
  const colors = {
    primary: "border-primary/25 bg-primary/5 text-primary",
    destructive: "border-destructive/25 bg-destructive/5 text-destructive",
    accent: "border-accent/25 bg-accent/5 text-accent",
    secondary: "border-secondary/25 bg-secondary/5 text-secondary",
  };
  return (
    <div className={cn("rounded-md border p-4 flex items-start gap-3", colors[color])}>
      <div className={cn("p-2 rounded border", colors[color])}>
        <Icon className="w-3.5 h-3.5" />
      </div>
      <div>
        <div className="text-2xl font-semibold">{value}</div>
        <div className="text-[10px] text-muted-foreground uppercase tracking-widest mt-0.5">{label}</div>
        {sub && <div className="text-[10px] text-muted-foreground mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

function SeverityBadge({ severity }: { severity?: string | null }) {
  const cls = severity
    ? ({
        critical: "risk-critical",
        high: "risk-high",
        medium: "risk-medium",
        low: "risk-low",
        info: "risk-info",
      }[severity] ?? "risk-info")
    : "risk-info";
  return (
    <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-widest", cls)}>
      {severity ?? "info"}
    </span>
  );
}

const ACTIVITY_ICONS: Record<string, React.ElementType> = {
  analysis_complete: CheckCircle,
  firmware_analyzed: Cpu,
  patch_applied: AlertTriangle,
  script_run: Terminal,
  model_response: Zap,
};

const MOCK_CHART = Array.from({ length: 14 }, (_, i) => ({
  day: `D-${13 - i}`,
  vulns: Math.floor(Math.random() * 8),
  analyses: Math.floor(Math.random() * 5) + 1,
}));

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats({ query: { refetchInterval: 10000 } });
  const { data: activity, isLoading: actLoading } = useGetRecentActivity({ query: { refetchInterval: 8000 } });

  return (
    <div className="p-6 space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] text-muted-foreground tracking-widest uppercase mb-1">Operational Dashboard</div>
          <h1 className="text-xl font-semibold text-foreground">SPECTER Control</h1>
        </div>
        <div className="flex items-center gap-3 text-[11px]">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-border bg-card">
            <div className={cn("w-1.5 h-1.5 rounded-full", stats?.ollamaOnline ? "bg-[hsl(145_55%_50%)] pulse-dot" : "bg-muted-foreground/30")} />
            <span className="text-muted-foreground">OLLAMA {stats?.ollamaOnline ? "ONLINE" : "OFFLINE"}</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border border-border bg-card">
            <div className={cn("w-1.5 h-1.5 rounded-full", stats?.ghidraMcpOnline ? "bg-[hsl(145_55%_50%)] pulse-dot" : "bg-muted-foreground/30")} />
            <span className="text-muted-foreground">GHIDRA MCP {stats?.ghidraMcpOnline ? "ONLINE" : "OFFLINE"}</span>
          </div>
        </div>
      </div>

      {/* Stat grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Projects" value={stats?.totalProjects ?? 0} icon={FolderOpen} color="primary" />
        <StatCard label="Binaries" value={stats?.totalBinaries ?? 0} icon={Binary} color="secondary" />
        <StatCard label="Firmware" value={stats?.totalFirmware ?? 0} icon={Cpu} color="secondary" />
        <StatCard label="All Vulns" value={stats?.totalVulnerabilities ?? 0} icon={ShieldAlert} color="accent" />
        <StatCard label="Critical" value={stats?.criticalVulnerabilities ?? 0} icon={AlertTriangle} color="destructive" />
        <StatCard label="Active Jobs" value={stats?.activeJobs ?? 0} icon={Activity} color="primary" sub={stats?.activeJobs ? "RUNNING" : "IDLE"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 rounded-md border border-border bg-card p-4">
          <div className="text-[11px] font-medium text-foreground mb-4">Analysis Activity <span className="text-muted-foreground font-normal">(14 days)</span></div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={MOCK_CHART} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="gradPurple" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(250 88% 69%)" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="hsl(250 88% 69%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradSlate" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(210 60% 58%)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="hsl(210 60% 58%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" tick={{ fill: "hsl(0 0% 42%)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(0 0% 42%)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "hsl(0 0% 14%)", border: "1px solid hsl(0 0% 20%)", borderRadius: 4, fontSize: 11, color: "hsl(0 0% 85%)" }}
                itemStyle={{ color: "hsl(250 88% 82%)" }}
              />
              <Area type="monotone" dataKey="analyses" stroke="hsl(250 88% 69%)" strokeWidth={1.5} fill="url(#gradPurple)" name="Analyses" />
              <Area type="monotone" dataKey="vulns" stroke="hsl(210 60% 58%)" strokeWidth={1.5} fill="url(#gradSlate)" name="Vulns Found" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Model info — agent banner: the one place purple bleeds into content */}
        <div className="rounded-md border border-border bg-card p-4 space-y-3 overflow-hidden">
          <div className="text-[11px] font-medium text-foreground">AI Engine</div>
          <div className="agent-banner rounded-sm px-3 py-2.5 space-y-1">
            <div className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-primary" />
              <span className="text-[13px] font-semibold text-primary">{stats?.modelName ?? "devstral-small"}</span>
            </div>
            <div className="text-[11px] text-muted-foreground">Local inference · reverse engineering specialised</div>
          </div>
          <div className="space-y-2 text-[11px]">
            {[["Backend", "Ollama"], ["Protocol", "MCP / HTTP"], ["Context", "128K tokens"], ["Mode", "Local / Offline"]].map(([k, v]) => (
              <div key={k} className="flex justify-between">
                <span className="text-muted-foreground">{k}</span>
                <span className="text-foreground/80">{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity feed */}
      <div className="rounded-md border border-border bg-card">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <div className="text-[11px] font-medium text-foreground">Recent Activity</div>
          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
        </div>
        <div className="divide-y divide-border">
          {actLoading ? (
            <div className="px-4 py-8 text-center text-muted-foreground text-[11px]">Loading activity...</div>
          ) : !activity?.length ? (
            <div className="px-4 py-8 text-center text-muted-foreground text-[11px]">No recent activity. Upload a binary or firmware to get started.</div>
          ) : (
            activity.slice(0, 8).map((item) => {
              const Icon = ACTIVITY_ICONS[item.type ?? ""] ?? Activity;
              return (
                <div key={item.id} className="px-4 py-3 flex items-start gap-3 hover:bg-muted/20 transition-colors">
                  <Icon className="w-3.5 h-3.5 mt-0.5 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] text-foreground">{item.title}</span>
                      <SeverityBadge severity={item.severity} />
                    </div>
                    <div className="text-[11px] text-muted-foreground truncate">{item.description}</div>
                  </div>
                  <div className="text-[10px] text-muted-foreground shrink-0">
                    {item.timestamp ? formatDistanceToNow(new Date(item.timestamp), { addSuffix: true }) : ""}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
