import { useGetDockerStatus, useStartDockerStack, useStopDockerStack, useListOllamaModels, usePullOllamaModel, getGetDockerStatusQueryKey, getListOllamaModelsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Container, Play, Square, Download, Zap, AlertTriangle, CheckCircle, Cpu, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

function ContainerCard({ c }: { c: { name: string; image: string; status: string; health: string; cpuPercent: number; memoryMb: number; ports: string } }) {
  const isUp = c.health === "healthy";
  return (
    <div className={cn("rounded-md border p-3 space-y-2", isUp ? "border-border bg-card" : "border-border bg-card")}>
      <div className="flex items-center gap-2">
        <div className={cn("w-2 h-2 rounded-full shrink-0 fill-current", isUp ? "bg-[hsl(145_55%_50%)] pulse-dot" : "bg-muted-foreground/30")} />
        <span className="text-[12px] font-medium text-foreground truncate">{c.name}</span>
        <span className={cn("ml-auto text-[9px] px-1.5 py-0.5 rounded border uppercase tracking-widest", isUp ? "risk-low" : "text-muted-foreground border-muted-foreground/30 bg-muted/20")}>{isUp ? "UP" : "DOWN"}</span>
      </div>
      <div className="text-[10px] text-muted-foreground font-mono truncate">{c.image}</div>
      {isUp && (
        <div className="grid grid-cols-2 gap-2 text-[10px]">
          <div className="flex justify-between px-2 py-1 rounded bg-muted/20">
            <span className="text-muted-foreground">CPU</span>
            <span className="text-foreground/80">{c.cpuPercent.toFixed(1)}%</span>
          </div>
          <div className="flex justify-between px-2 py-1 rounded bg-muted/20">
            <span className="text-muted-foreground">RAM</span>
            <span className="text-foreground/80">{c.memoryMb >= 1024 ? `${(c.memoryMb / 1024).toFixed(1)}G` : `${c.memoryMb}M`}</span>
          </div>
        </div>
      )}
      {c.ports && <div className="text-[10px] text-secondary font-mono">{c.ports}</div>}
    </div>
  );
}

function ModelCard({ model, onPull }: { model: { name: string; sizeGb: number; family: string; quantization: string; fitsIn16Gb: boolean; recommended: boolean; pulledAt?: string | null }; onPull: () => void }) {
  return (
    <div className={cn("rounded border p-3 space-y-2", model.recommended ? "border-primary/30 bg-primary/5" : "border-border bg-card")}>
      <div className="flex items-center gap-2">
        {model.recommended && <Zap className="w-3 h-3 text-primary shrink-0" />}
        <span className="text-[12px] font-bold text-foreground truncate">{model.name}</span>
        {model.recommended && <span className="ml-auto text-[9px] px-1.5 py-0.5 rounded border risk-low uppercase tracking-widest">recommended</span>}
      </div>
      <div className="grid grid-cols-3 gap-1.5 text-[10px]">
        <div className="px-1.5 py-1 rounded bg-muted/20 text-center">
          <div className="text-muted-foreground">Size</div>
          <div className="text-foreground">{model.sizeGb}GB</div>
        </div>
        <div className="px-1.5 py-1 rounded bg-muted/20 text-center">
          <div className="text-muted-foreground">Quant</div>
          <div className="text-foreground text-[9px]">{model.quantization}</div>
        </div>
        <div className="px-1.5 py-1 rounded bg-muted/20 text-center">
          <div className="text-muted-foreground">16GB</div>
          <div className={model.fitsIn16Gb ? "text-primary" : "text-destructive"}>{model.fitsIn16Gb ? "✓" : "✗"}</div>
        </div>
      </div>
      <Button
        data-testid={`button-pull-model-${model.name}`}
        size="sm"
        onClick={onPull}
        className={cn("w-full h-7 text-[10px] uppercase tracking-wider gap-1.5", model.pulledAt ? "bg-muted/20 border border-border text-muted-foreground" : "bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20")}
      >
        <Download className="w-3 h-3" />
        {model.pulledAt ? "Installed" : "Pull Model"}
      </Button>
    </div>
  );
}

export default function Docker() {
  const { data: status, isLoading: statusLoading } = useGetDockerStatus({ query: { refetchInterval: 8000 } });
  const { data: models } = useListOllamaModels({ query: { refetchInterval: 15000 } });
  const startStack = useStartDockerStack();
  const stopStack = useStopDockerStack();
  const pullModel = usePullOllamaModel();
  const qc = useQueryClient();
  const { toast } = useToast();

  const handleStart = () => {
    startStack.mutate(undefined, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetDockerStatusQueryKey() });
        toast({ title: "Stack starting", description: "Docker Compose initiating services..." });
      },
    });
  };

  const handleStop = () => {
    if (!confirm("Stop the SPECTER Docker stack? This will stop Ghidra MCP and Ollama.")) return;
    stopStack.mutate(undefined, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetDockerStatusQueryKey() });
        toast({ title: "Stack stopped" });
      },
    });
  };

  const handlePull = (name: string) => {
    pullModel.mutate(
      { data: { modelName: name } },
      { onSuccess: () => toast({ title: `Pulling ${name}`, description: "Check Docker logs for progress — this may take 10-15 minutes" }) }
    );
  };

  const dockerCfg = `version: '3.9'
services:
  ghidra-mcp:
    image: ghidra-mcp:latest
    ports: ["9090:9090"]
    volumes: ["./projects:/projects"]
    environment:
      - GHIDRA_HEADLESS=true

  ollama:
    image: ollama/ollama:latest
    ports: ["11434:11434"]
    volumes: ["ollama_data:/root/.ollama"]
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: all
              capabilities: [gpu]

volumes:
  ollama_data:`;

  return (
    <div className="p-6 space-y-6 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] text-muted-foreground uppercase mb-1">Docker Compose Stack</div>
          <h1 className="text-xl font-semibold text-foreground">Stack Manager</h1>
        </div>
        <div className="flex items-center gap-3">
          <Button
            data-testid="button-start-stack"
            size="sm"
            onClick={handleStart}
            disabled={startStack.isPending || status?.stackRunning}
            className="bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 text-[12px] gap-1.5 h-8"
          >
            <Play className="w-3.5 h-3.5" /> Start Stack
          </Button>
          <Button
            data-testid="button-stop-stack"
            size="sm"
            onClick={handleStop}
            disabled={stopStack.isPending || !status?.stackRunning}
            className="bg-destructive/10 border border-destructive/30 text-destructive hover:bg-destructive/20 text-[11px] uppercase tracking-wider gap-1.5 h-8"
          >
            <Square className="w-3.5 h-3.5" /> Stop Stack
          </Button>
        </div>
      </div>

      {/* Status bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Docker", val: status?.dockerAvailable ? "AVAILABLE" : "UNAVAILABLE", ok: status?.dockerAvailable },
          { label: "Stack", val: status?.stackRunning ? "RUNNING" : "STOPPED", ok: status?.stackRunning },
          { label: "Ghidra MCP", val: status?.ghidraMcpUrl ?? "localhost:9090", ok: status?.stackRunning },
          { label: "Ollama API", val: status?.ollamaUrl ?? "localhost:11434", ok: status?.stackRunning },
        ].map(({ label, val, ok }) => (
          <div key={label} className="rounded-md border border-border bg-card p-3">
            <div className="text-[10px] text-muted-foreground uppercase tracking-widest">{label}</div>
            <div className={cn("text-[12px] font-medium mt-1 truncate", ok ? "text-foreground" : "text-muted-foreground")}>{val}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Containers */}
        <div className="space-y-3">
          <div className="text-[11px] font-medium text-foreground">Running Containers</div>
          {statusLoading ? (
            <div className="text-muted-foreground text-[12px]">Loading...</div>
          ) : !status?.containers?.length ? (
            <div className="rounded-md border border-border bg-card p-8 text-center dot-bg">
              <Container className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <div className="text-[12px] text-muted-foreground">No containers running</div>
              <div className="text-[11px] text-muted-foreground/60 mt-1">Start the Docker stack to launch Ghidra MCP + Ollama</div>
            </div>
          ) : (
            <div className="space-y-2">
              {(status.containers as Array<{ name: string; image: string; status: string; health: string; cpuPercent: number; memoryMb: number; ports: string }>).map((c) => (
                <ContainerCard key={c.name} c={c} />
              ))}
            </div>
          )}
        </div>

        {/* Ollama Models */}
        <div className="space-y-3">
          <div className="text-[11px] font-medium text-foreground">Ollama Models</div>
          <div className="grid gap-2">
            {(models as Array<{ name: string; sizeGb: number; family: string; quantization: string; fitsIn16Gb: boolean; recommended: boolean; pulledAt?: string | null }> | undefined)?.map((m) => (
              <ModelCard key={m.name} model={m} onPull={() => handlePull(m.name)} />
            ))}
          </div>
        </div>
      </div>

      {/* Docker Compose config */}
      <div className="space-y-2">
        <div className="text-[11px] font-medium text-foreground">docker-compose.yml Template</div>
        <div className="rounded-md border border-border bg-card overflow-hidden">
          <div className="px-3 py-2 border-b border-border bg-muted/30 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-destructive/50" />
            <div className="w-2 h-2 rounded-full bg-accent/50" />
            <div className="w-2 h-2 rounded-full bg-muted-foreground/30" />
            <span className="text-[10px] text-muted-foreground ml-2 font-mono">docker-compose.yml</span>
          </div>
          <pre className="p-4 text-[11px] text-foreground/70 font-mono overflow-x-auto leading-relaxed">{dockerCfg}</pre>
        </div>
      </div>
    </div>
  );
}
