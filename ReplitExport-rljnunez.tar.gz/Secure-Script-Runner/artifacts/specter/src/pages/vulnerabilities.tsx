import { useState } from "react";
import { useListVulnerabilities, useGetVulnerabilityStats } from "@workspace/api-client-react";
import { ShieldAlert, AlertTriangle, X, Filter, ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";

function SevBadge({ severity }: { severity: string }) {
  const cls: Record<string, string> = {
    critical: "risk-critical",
    high: "risk-high",
    medium: "risk-medium",
    low: "risk-low",
    info: "risk-info",
  };
  return <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-widest", cls[severity] ?? cls.info)}>{severity}</span>;
}

const SEV_COLORS: Record<string, string> = {
  critical: "hsl(4 100% 58%)",
  high: "hsl(28 100% 58%)",
  medium: "hsl(38 100% 55%)",
  low: "hsl(145 100% 45%)",
  info: "hsl(193 100% 42%)",
};

export default function Vulnerabilities() {
  const [severityFilter, setSeverityFilter] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const { data: vulns, isLoading } = useListVulnerabilities(
    severityFilter ? { severity: severityFilter } : undefined,
    { query: { refetchInterval: 8000 } }
  );
  const { data: stats } = useGetVulnerabilityStats({ query: { refetchInterval: 10000 } });

  const chartData = stats
    ? [
        { name: "Critical", value: stats.critical, key: "critical" },
        { name: "High", value: stats.high, key: "high" },
        { name: "Medium", value: stats.medium, key: "medium" },
        { name: "Low", value: stats.low, key: "low" },
      ].filter((d) => d.value > 0)
    : [];

  const SEVS = ["critical", "high", "medium", "low", "info"];

  return (
    <div className="p-6 space-y-5 max-w-6xl">
      <div>
        <div className="text-[10px] text-muted-foreground uppercase mb-1">Automated Scanner</div>
        <h1 className="text-xl font-semibold text-foreground">Vulnerabilities</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Pie chart */}
        <div className="rounded-md border border-border bg-card p-4">
          <div className="text-[11px] font-medium text-foreground mb-3">Distribution</div>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={65} innerRadius={35} strokeWidth={0}>
                  {chartData.map((entry) => (
                    <Cell key={entry.key} fill={SEV_COLORS[entry.key]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "hsl(0 0% 14%)", border: "1px solid hsl(0 0% 20%)", fontSize: 11, color: "hsl(0 0% 85%)" }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-40 flex items-center justify-center text-muted-foreground text-[11px]">No vulnerability data</div>
          )}
        </div>

        {/* Stats */}
        <div className="md:col-span-2 rounded-md border border-border bg-card p-4">
          <div className="text-[11px] font-medium text-foreground mb-3">Summary</div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Total", value: stats?.total ?? 0, cls: "text-foreground" },
              { label: "Critical", value: stats?.critical ?? 0, cls: "text-destructive" },
              { label: "High", value: stats?.high ?? 0, cls: "text-orange-400" },
              { label: "Medium", value: stats?.medium ?? 0, cls: "text-accent" },
              { label: "Low", value: stats?.low ?? 0, cls: "text-primary" },
              { label: "Patchable", value: stats?.patchable ?? 0, cls: "text-secondary" },
            ].map(({ label, value, cls }) => (
              <div key={label} className="rounded border border-border bg-muted/20 p-3">
                <div className={cn("text-2xl font-bold tracking-widest", cls)}>{value}</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="w-3.5 h-3.5 text-muted-foreground" />
        <button
          onClick={() => setSeverityFilter(null)}
          className={cn("text-[10px] px-2.5 py-1 rounded border uppercase tracking-wider transition-colors", severityFilter === null ? "border-primary text-primary bg-primary/10" : "border-border text-muted-foreground hover:border-muted-foreground/50")}
        >
          ALL
        </button>
        {SEVS.map((sev) => (
          <button
            key={sev}
            onClick={() => setSeverityFilter(sev === severityFilter ? null : sev)}
            className={cn("text-[10px] px-2.5 py-1 rounded border uppercase tracking-wider transition-colors",
              severityFilter === sev ? cn(SEV_COLORS[sev] ? "" : "", "border-current") : "border-border text-muted-foreground hover:border-muted-foreground/50",
              severityFilter === sev && sev === "critical" ? "risk-critical" : "",
              severityFilter === sev && sev === "high" ? "risk-high" : "",
              severityFilter === sev && sev === "medium" ? "risk-medium" : "",
              severityFilter === sev && sev === "low" ? "risk-low" : "",
              severityFilter === sev && sev === "info" ? "risk-info" : "",
            )}
          >
            {sev}
          </button>
        ))}
      </div>

      {/* Vuln list */}
      {isLoading ? (
        <div className="text-muted-foreground text-[12px]">Loading...</div>
      ) : !vulns?.length ? (
        <div className="rounded-md border border-border bg-card p-12 text-center dot-bg">
          <ShieldAlert className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <div className="text-[13px] text-muted-foreground">No vulnerabilities found</div>
          <div className="text-[11px] text-muted-foreground/60 mt-1">Run binary or firmware analysis to discover vulnerabilities</div>
        </div>
      ) : (
        <div className="space-y-2">
          {vulns.map((v) => (
            <div key={v.id} className="rounded border border-border bg-card overflow-hidden">
              <div
                data-testid={`card-vuln-${v.id}`}
                className="px-4 py-3 flex items-start gap-3 cursor-pointer hover:bg-muted/20 transition-colors"
                onClick={() => setExpanded(expanded === v.id ? null : v.id)}
              >
                <AlertTriangle className={cn("w-4 h-4 mt-0.5 shrink-0", v.severity === "critical" ? "text-destructive" : v.severity === "high" ? "text-orange-400" : "text-accent")} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[12px] font-bold text-foreground">{v.title}</span>
                    <SevBadge severity={v.severity} />
                    {v.cveId && <span className="text-[9px] px-1.5 py-0.5 rounded border risk-info">{v.cveId}</span>}
                    {v.isPatchable && <span className="text-[9px] px-1.5 py-0.5 rounded border text-secondary border-secondary/30 bg-secondary/10">PATCHABLE</span>}
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-0.5 truncate">{v.description}</div>
                  <div className="text-[10px] text-muted-foreground/60 mt-0.5 flex items-center gap-2">
                    {v.address && <span className="font-mono">{v.address}</span>}
                    <span>{v.category}</span>
                    {v.riskScore && <span className={cn("font-bold", v.riskScore >= 9 ? "text-destructive" : v.riskScore >= 7 ? "text-orange-400" : "text-accent")}>CVSS {v.riskScore?.toFixed(1)}</span>}
                  </div>
                </div>
                <ChevronRight className={cn("w-4 h-4 text-muted-foreground shrink-0 transition-transform", expanded === v.id ? "rotate-90" : "")} />
              </div>
              {expanded === v.id && (
                <div className="px-4 pb-4 border-t border-border pt-3 space-y-3">
                  <div>
                    <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Description</div>
                    <div className="text-[12px] text-foreground leading-relaxed">{v.description}</div>
                  </div>
                  {v.remediation && (
                    <div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">Remediation</div>
                      <div className="text-[12px] text-primary leading-relaxed">{v.remediation}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
