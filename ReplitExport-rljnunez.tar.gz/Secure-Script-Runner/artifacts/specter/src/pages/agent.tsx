import { useState, useRef, useEffect } from "react";
import {
  useListAgentSessions,
  useCreateAgentSession,
  useGetAgentSession,
  useSendAgentMessage,
  useGenerateAgentPlan,
  useGetAgentPlan,
  useApproveAgentPlan,
  useGetAgentRuntimeStatus,
  getListAgentSessionsQueryKey,
  getGetAgentSessionQueryKey,
  getGetAgentPlanQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Bot, Plus, Send, Zap, AlertTriangle, Terminal, CheckCircle2,
  XCircle, Clock, ChevronRight, Play, ShieldAlert, Activity,
  Wrench, CircleDot,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { formatDistanceToNow } from "date-fns";
import ReactMarkdown from "react-markdown";

const MODELS = [
  { value: "Qwen/Qwen3-Coder-30B-A3B-Instruct", label: "Qwen3-Coder-30B (vLLM primary)" },
  { value: "qwen3:8b", label: "Qwen3-8B (fast/triage)" },
  { value: "devstral-small", label: "devstral-small (Ollama fallback)" },
  { value: "codestral:22b-q4_K_M", label: "codestral:22b (Ollama advanced)" },
];

const SUGGESTED = [
  "Analyze the network connections and C2 infrastructure in the loaded binary",
  "What UEFI vulnerabilities are present? Assess exploitability.",
  "Identify anti-debugging techniques and suggest bypass methods",
  "Describe the encryption algorithm used and reverse the key schedule",
  "Generate a Ghidra script to find all call sites of CreateRemoteThread",
];

type InputMode = "ask" | "plan";

// ── Runtime status chip ────────────────────────────────────────────────────

function RuntimeChip() {
  const { data } = useGetAgentRuntimeStatus({ query: { refetchInterval: 15000 } });
  const active = data?.active ?? "simulation";
  const config = {
    vllm: { label: "vLLM", cls: "text-[hsl(145_55%_55%)] border-[hsl(145_55%_40%/0.4)] bg-[hsl(145_55%_50%/0.08)]" },
    ollama: { label: "Ollama", cls: "text-primary border-primary/30 bg-primary/8" },
    simulation: { label: "Simulation", cls: "text-muted-foreground border-border/60 bg-muted/20" },
  }[active];

  return (
    <div className={cn("flex items-center gap-1.5 text-[10px] font-medium px-2 py-1 rounded border", config.cls)}>
      <CircleDot className="w-2.5 h-2.5" />
      {config.label}
      {data?.vllm && <span className="opacity-60">· vLLM</span>}
      {!data?.vllm && data?.ollama && <span className="opacity-60">· Ollama</span>}
    </div>
  );
}

// ── Risk badge ─────────────────────────────────────────────────────────────

function RiskBadge({ level, label }: { level: number; label: string }) {
  const cls =
    level >= 9 ? "risk-critical" :
    level >= 7 ? "risk-high" :
    level >= 4 ? "risk-medium" :
    "risk-low";
  return (
    <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-widest", cls)}>
      {label} {level}/10
    </span>
  );
}

// ── Tool badge ─────────────────────────────────────────────────────────────

function ToolBadge({ tool }: { tool: string }) {
  return (
    <span className="text-[10px] font-mono text-primary/70 bg-primary/8 px-1.5 py-0.5 rounded border border-primary/20">
      {tool}
    </span>
  );
}

// ── Step status icon ───────────────────────────────────────────────────────

function StepIcon({ status }: { status: string }) {
  switch (status) {
    case "complete":   return <CheckCircle2 className="w-4 h-4 text-[hsl(145_55%_50%)] shrink-0" />;
    case "executing":  return <Activity className="w-4 h-4 text-primary animate-pulse shrink-0" />;
    case "failed":
    case "blocked":    return <XCircle className="w-4 h-4 text-destructive shrink-0" />;
    case "approved":   return <Clock className="w-4 h-4 text-muted-foreground shrink-0" />;
    default:           return <CircleDot className="w-4 h-4 text-muted-foreground/40 shrink-0" />;
  }
}

// ── Plan step card ─────────────────────────────────────────────────────────

interface PlanStep {
  id: string;
  stepOrder: number;
  tool: string;
  description: string;
  riskLevel: number;
  riskLabel: string;
  requiresApproval: boolean;
  status: string;
  output?: string | null;
  error?: string | null;
  retries: number;
}

function PlanStepCard({ step, checked, onToggle, isExecuting }: {
  step: PlanStep;
  checked: boolean;
  onToggle: () => void;
  isExecuting: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={cn(
      "rounded-md border transition-all duration-200",
      step.status === "complete" ? "border-[hsl(145_55%_40%/0.3)] bg-[hsl(145_55%_50%/0.04)]" :
      step.status === "executing" ? "border-primary/30 bg-primary/4" :
      step.status === "blocked" || step.status === "failed" ? "border-destructive/30 bg-destructive/4" :
      "border-border bg-card/50"
    )}>
      <div className="flex items-start gap-3 p-3">
        <div className="flex items-center gap-2 mt-0.5 shrink-0">
          <span className="text-[10px] text-muted-foreground w-4 text-right">{step.stepOrder}</span>
          <StepIcon status={step.status} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <ToolBadge tool={step.tool} />
            {step.riskLevel >= 4 && <RiskBadge level={step.riskLevel} label={step.riskLabel} />}
            {step.retries > 0 && (
              <span className="text-[9px] text-amber-400/80">↺ {step.retries} retries</span>
            )}
          </div>
          <div className="text-[11px] text-foreground/80 mt-1 leading-snug">{step.description}</div>
          {step.output && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="text-[10px] text-primary/60 hover:text-primary mt-1 flex items-center gap-1"
            >
              <ChevronRight className={cn("w-3 h-3 transition-transform", expanded && "rotate-90")} />
              {expanded ? "Hide output" : "Show output"}
            </button>
          )}
          {expanded && step.output && (
            <pre className="mt-2 text-[10px] font-mono text-foreground/70 bg-muted/30 rounded p-2 overflow-x-auto leading-relaxed border border-border/50 max-h-40 overflow-y-auto">
              {step.output}
            </pre>
          )}
          {step.error && step.status === "blocked" && (
            <div className="mt-2 text-[10px] text-destructive/80 bg-destructive/5 rounded p-2 border border-destructive/20 font-mono">
              BLOCKED: {step.error}
            </div>
          )}
        </div>
        {/* Approval checkbox for HIGH/CRITICAL steps when pending */}
        {step.requiresApproval && !isExecuting && step.status === "pending" && (
          <label className="flex items-center gap-1.5 cursor-pointer shrink-0 mt-0.5">
            <input
              type="checkbox"
              checked={checked}
              onChange={onToggle}
              className="w-3.5 h-3.5 accent-[hsl(4_85%_60%)] rounded"
            />
            <span className="text-[9px] text-destructive uppercase tracking-wide">I approve</span>
          </label>
        )}
      </div>
    </div>
  );
}

// ── Plan card (the approve panel) ──────────────────────────────────────────

interface AgentPlan {
  id: string;
  sessionId: string;
  query: string;
  status: string;
  activeRuntime?: string | null;
  modelUsed?: string | null;
  reflectionSummary?: string | null;
  steps: PlanStep[];
}

function PlanCard({ planId, sessionId, onComplete }: { planId: string; sessionId: string; onComplete: () => void }) {
  const qc = useQueryClient();
  const [approvedIds, setApprovedIds] = useState<Set<string>>(new Set());
  const approvePlan = useApproveAgentPlan();

  const isExecuting = (plan: AgentPlan) =>
    plan.status === "executing" || plan.status === "complete" || plan.status === "blocked";

  const { data: plan } = useGetAgentPlan(planId, {
    query: {
      refetchInterval: (query) => {
        const data = query.state.data as AgentPlan | undefined;
        if (!data) return 2000;
        if (data.status === "complete" || data.status === "blocked") return false;
        return data.status === "executing" ? 1200 : false;
      },
      onSuccess: (data: AgentPlan) => {
        if (data.status === "complete") {
          qc.invalidateQueries({ queryKey: getGetAgentSessionQueryKey(sessionId) });
          onComplete();
        }
      },
    },
  });

  if (!plan) return (
    <div className="rounded-md border border-border bg-card/50 p-4 text-[11px] text-muted-foreground animate-pulse">
      Generating analysis plan...
    </div>
  );

  const executing = isExecuting(plan as AgentPlan);
  const highRiskSteps = (plan as AgentPlan).steps.filter((s) => s.requiresApproval && s.status === "pending");
  const unapprovedHighRisk = highRiskSteps.filter((s) => !approvedIds.has(s.id));
  const canApprove = !executing && unapprovedHighRisk.length === 0;

  const handleApprove = () => {
    approvePlan.mutate(
      { planId, data: { approvedStepIds: Array.from(approvedIds) } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getGetAgentPlanQueryKey(planId) });
        },
      }
    );
  };

  const completedCount = (plan as AgentPlan).steps.filter((s) => s.status === "complete").length;
  const totalCount = (plan as AgentPlan).steps.length;

  return (
    <div className="agent-banner rounded-md p-4 space-y-3">
      {/* Plan header */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Wrench className="w-3.5 h-3.5 text-primary" />
            <span className="text-[12px] font-semibold text-primary">Analysis Plan</span>
            <span className={cn("text-[9px] px-1.5 py-0.5 rounded border uppercase tracking-widest font-bold",
              (plan as AgentPlan).status === "complete" ? "risk-low" :
              (plan as AgentPlan).status === "blocked" ? "risk-critical" :
              (plan as AgentPlan).status === "executing" ? "text-primary border-primary/30 bg-primary/10" :
              "text-muted-foreground border-muted-foreground/30 bg-muted/20"
            )}>
              {(plan as AgentPlan).status}
            </span>
          </div>
          <div className="text-[11px] text-muted-foreground">"{(plan as AgentPlan).query.slice(0, 80)}{(plan as AgentPlan).query.length > 80 ? "…" : ""}"</div>
          {(plan as AgentPlan).activeRuntime && (
            <div className="text-[10px] text-muted-foreground/60 mt-0.5">
              Runtime: <span className="text-foreground/60">{(plan as AgentPlan).activeRuntime}</span>
              {(plan as AgentPlan).modelUsed && <> · {(plan as AgentPlan).modelUsed?.split("/").pop()}</>}
            </div>
          )}
        </div>
        {executing && (plan as AgentPlan).status === "executing" && (
          <div className="text-[11px] text-primary shrink-0">{completedCount}/{totalCount}</div>
        )}
      </div>

      {/* Progress bar when executing */}
      {executing && totalCount > 0 && (plan as AgentPlan).status !== "blocked" && (
        <div className="w-full h-1 rounded-full bg-muted/40 overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${(completedCount / totalCount) * 100}%` }}
          />
        </div>
      )}

      {/* Steps */}
      <div className="space-y-2">
        {(plan as AgentPlan).steps.map((step) => (
          <PlanStepCard
            key={step.id}
            step={step}
            checked={approvedIds.has(step.id)}
            onToggle={() => {
              setApprovedIds((prev) => {
                const next = new Set(prev);
                if (next.has(step.id)) next.delete(step.id);
                else next.add(step.id);
                return next;
              });
            }}
            isExecuting={executing}
          />
        ))}
      </div>

      {/* Blocked state */}
      {(plan as AgentPlan).status === "blocked" && (
        <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-[11px] text-destructive/80">
          <div className="flex items-center gap-2 font-semibold mb-1">
            <XCircle className="w-3.5 h-3.5" /> BLOCKED — execution halted after 3 retries
          </div>
          <div className="text-[10px] text-destructive/60">Review the failed step above. Edit your query or adjust the plan and try again.</div>
        </div>
      )}

      {/* Approve button when pending */}
      {!executing && (plan as AgentPlan).status === "pending" && (
        <div className="pt-1 space-y-2">
          {highRiskSteps.length > 0 && unapprovedHighRisk.length > 0 && (
            <div className="flex items-center gap-2 text-[10px] text-amber-400/80">
              <ShieldAlert className="w-3.5 h-3.5" />
              {unapprovedHighRisk.length} HIGH/CRITICAL step{unapprovedHighRisk.length > 1 ? "s" : ""} require explicit approval above
            </div>
          )}
          <Button
            size="sm"
            onClick={handleApprove}
            disabled={!canApprove || approvePlan.isPending}
            className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 text-[12px] w-full"
          >
            <Play className="w-3.5 h-3.5" />
            {approvePlan.isPending ? "Starting…" : `Approve & Execute ${totalCount} Steps`}
          </Button>
          <div className="text-[10px] text-muted-foreground/60 text-center">
            Stage 2 of 5 — Review each step. HIGH/CRITICAL steps require explicit checkbox approval.
          </div>
        </div>
      )}
    </div>
  );
}

// ── Message bubble ─────────────────────────────────────────────────────────

interface MessageData {
  id: string;
  role: string;
  content: string;
  riskLevel?: number | null;
  reasoning?: string | null;
  evidence?: string[] | null;
  planId?: string | null;
  timestamp: string;
}

function Message({ msg, sessionId, onPlanComplete }: { msg: MessageData; sessionId: string; onPlanComplete: () => void }) {
  const isUser = msg.role === "user";
  const [showPlan, setShowPlan] = useState(true);

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div className="max-w-[75%] rounded-md border border-border bg-muted/20 px-3.5 py-2.5">
          <div className="text-[12px] text-foreground/90 leading-relaxed">{msg.content}</div>
          <div className="text-[9px] text-muted-foreground mt-1 text-right">
            {formatDistanceToNow(new Date(msg.timestamp), { addSuffix: true })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3">
      <div className="w-6 h-6 rounded border border-primary/30 bg-primary/8 flex items-center justify-center shrink-0 mt-0.5">
        <Bot className="w-3.5 h-3.5 text-primary" />
      </div>
      <div className="flex-1 min-w-0 space-y-2">
        {/* Plan card — shows inline before the reflection */}
        {msg.planId && showPlan && (
          <PlanCard planId={msg.planId} sessionId={sessionId} onComplete={() => { setShowPlan(false); onPlanComplete(); }} />
        )}
        {/* Message content (reflection / chat) */}
        {!msg.planId || !showPlan || msg.content ? (
          <div className="rounded-md border border-border bg-card/50 px-4 py-3">
            <div className="prose prose-sm prose-invert max-w-none text-[12px] leading-relaxed [&_pre]:bg-muted/40 [&_pre]:rounded [&_pre]:p-2 [&_pre]:text-[10px] [&_code]:text-primary/80 [&_strong]:text-foreground">
              <ReactMarkdown>{msg.content}</ReactMarkdown>
            </div>
            {/* Metadata */}
            <div className="mt-2 pt-2 border-t border-border/40 flex items-center gap-3 flex-wrap">
              {msg.riskLevel != null && msg.riskLevel > 0 && (
                <RiskBadge level={msg.riskLevel} label={msg.riskLevel >= 9 ? "critical" : msg.riskLevel >= 7 ? "high" : msg.riskLevel >= 4 ? "medium" : "low"} />
              )}
              {msg.evidence && msg.evidence.length > 0 && (
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                  <Terminal className="w-3 h-3" />
                  {msg.evidence.slice(0, 2).join(" · ")}
                  {msg.evidence.length > 2 && <span className="opacity-60">+{msg.evidence.length - 2}</span>}
                </div>
              )}
              <div className="ml-auto text-[9px] text-muted-foreground">
                {formatDistanceToNow(new Date(msg.timestamp), { addSuffix: true })}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

// ── Typing indicator ───────────────────────────────────────────────────────

function TypingIndicator() {
  return (
    <div className="flex gap-3">
      <div className="w-6 h-6 rounded border border-primary/30 bg-primary/8 flex items-center justify-center shrink-0">
        <Bot className="w-3.5 h-3.5 text-primary" />
      </div>
      <div className="rounded-md border border-border bg-card/50 px-4 py-3 flex items-center gap-1.5">
        {[0, 150, 300].map((delay) => (
          <div key={delay} className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: `${delay}ms` }} />
        ))}
      </div>
    </div>
  );
}

// ── Main agent page ────────────────────────────────────────────────────────

export default function Agent() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [inputMode, setInputMode] = useState<InputMode>("plan");
  const [newOpen, setNewOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newModel, setNewModel] = useState("devstral-small");
  const [activePlanId, setActivePlanId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: sessions, isLoading } = useListAgentSessions({ query: { refetchInterval: 8000 } });
  const { data: session } = useGetAgentSession(selectedId ?? "", {
    query: { enabled: !!selectedId, refetchInterval: activePlanId ? 3000 : false },
  });

  const createSession = useCreateAgentSession();
  const sendMessage = useSendAgentMessage();
  const generatePlan = useGenerateAgentPlan();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [session?.messages?.length]);

  const handleCreate = () => {
    createSession.mutate(
      { data: { title: newTitle || "Analysis Session", model: newModel } },
      {
        onSuccess: (s) => {
          qc.invalidateQueries({ queryKey: getListAgentSessionsQueryKey() });
          setSelectedId(s.id);
          setNewOpen(false);
          setNewTitle("");
        },
      }
    );
  };

  const handleSend = () => {
    if (!input.trim() || !selectedId) return;
    const query = input.trim();
    setInput("");

    if (inputMode === "plan") {
      // Generate structured plan
      generatePlan.mutate(
        { id: selectedId, data: { query } },
        {
          onSuccess: (plan) => {
            setActivePlanId(plan.id);
            qc.invalidateQueries({ queryKey: getGetAgentSessionQueryKey(selectedId) });
          },
          onError: () => toast({ title: "Plan generation failed", variant: "destructive" }),
        }
      );
    } else {
      // Direct chat message
      sendMessage.mutate(
        { id: selectedId, data: { content: query } },
        {
          onSuccess: () => {
            qc.invalidateQueries({ queryKey: getGetAgentSessionQueryKey(selectedId) });
            qc.invalidateQueries({ queryKey: getListAgentSessionsQueryKey() });
          },
          onError: () => toast({ title: "Message failed", variant: "destructive" }),
        }
      );
    }
  };

  const isPending = sendMessage.isPending || generatePlan.isPending;

  return (
    <div className="flex h-screen overflow-hidden" style={{ maxHeight: "100vh" }}>
      {/* Sessions sidebar */}
      <div className="w-52 shrink-0 border-r border-border flex flex-col bg-card/40">
        <div className="px-3 py-3 border-b border-border flex items-center justify-between">
          <div className="text-[11px] font-medium text-foreground">Sessions</div>
          <button
            data-testid="button-new-session"
            onClick={() => setNewOpen(true)}
            className="w-6 h-6 rounded border border-primary/40 flex items-center justify-center text-primary hover:bg-primary/10 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto py-2 space-y-px">
          {isLoading ? (
            <div className="text-muted-foreground text-[11px] px-4 py-3">Loading...</div>
          ) : !sessions?.length ? (
            <div className="text-muted-foreground text-[11px] px-4 py-6 text-center">No sessions yet</div>
          ) : (
            sessions.map((s) => (
              <div
                key={s.id}
                data-testid={`card-session-${s.id}`}
                onClick={() => { setSelectedId(s.id); setActivePlanId(null); }}
                className={cn(
                  "px-3 py-2.5 cursor-pointer transition-all",
                  selectedId === s.id ? "nav-active" : "nav-inactive"
                )}
              >
                <div className="text-[11px] font-medium truncate">{s.title}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5 flex justify-between">
                  <span className="truncate opacity-70">{s.model?.split("/").pop()?.split(":")[0]}</span>
                  <span className="opacity-50">{s.messageCount}msg</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Header */}
        <div className="px-5 py-2.5 border-b border-border flex items-center gap-3">
          <Zap className="w-4 h-4 text-primary shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[12px] font-semibold text-foreground truncate">
              {session ? session.title : "SPECTER AI Agent"}
            </div>
            {session && (
              <div className="text-[10px] text-muted-foreground">
                {session.messageCount} messages · {session.model?.split("/").pop()}
              </div>
            )}
          </div>
          <RuntimeChip />
        </div>

        {/* Intelligence feed */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {!selectedId ? (
            /* Welcome state */
            <div className="flex flex-col items-center justify-center h-full space-y-6 text-center">
              <div>
                <Bot className="w-10 h-10 text-primary/25 mx-auto mb-3" />
                <div className="text-[15px] font-semibold text-foreground">SPECTER AI Agent</div>
                <div className="text-[11px] text-muted-foreground mt-1 max-w-xs leading-relaxed">
                  Plan → Approve → Execute → Test → Reflect.<br />
                  Every operation surfaces risk before it runs.
                </div>
              </div>
              <div className="space-y-2 w-full max-w-md">
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-2">Suggested queries</div>
                {SUGGESTED.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => setNewOpen(true)}
                    className="w-full text-left px-3 py-2.5 rounded-md border border-border text-[11px] text-muted-foreground hover:text-foreground hover:border-primary/30 hover:bg-primary/4 transition-all"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : !session?.messages?.length ? (
            /* Empty session */
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Bot className="w-8 h-8 text-primary/20 mx-auto mb-2" />
              <div className="text-[12px] text-muted-foreground font-medium">Start an analysis</div>
              <div className="text-[11px] text-muted-foreground/60 mt-1">Type a query below — use Plan mode for structured multi-step analysis</div>
              <div className="mt-5 space-y-2 w-full max-w-sm">
                {SUGGESTED.slice(0, 3).map((s, i) => (
                  <button key={i} onClick={() => { setInput(s); setInputMode("plan"); }}
                    className="w-full text-left px-3 py-2 rounded-md border border-border text-[11px] text-muted-foreground hover:text-foreground hover:border-primary/30 hover:bg-primary/4 transition-all">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Messages */
            session.messages.map((msg) => (
              <Message
                key={msg.id}
                msg={msg as MessageData}
                sessionId={selectedId}
                onPlanComplete={() => {
                  setActivePlanId(null);
                  qc.invalidateQueries({ queryKey: getGetAgentSessionQueryKey(selectedId) });
                }}
              />
            ))
          )}

          {/* Pending indicator */}
          {isPending && <TypingIndicator />}
          <div ref={bottomRef} />
        </div>

        {/* Input area */}
        {selectedId && (
          <div className="px-5 py-4 border-t border-border">
            {/* Mode toggle */}
            <div className="flex gap-1 mb-3">
              {(["plan", "ask"] as InputMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setInputMode(mode)}
                  className={cn(
                    "px-3 py-1 rounded text-[11px] font-medium transition-all",
                    inputMode === mode
                      ? "bg-primary/12 text-primary border border-primary/30"
                      : "text-muted-foreground hover:text-foreground border border-transparent"
                  )}
                >
                  {mode === "plan" ? (
                    <span className="flex items-center gap-1.5"><Wrench className="w-3 h-3" /> Plan Mode</span>
                  ) : (
                    <span className="flex items-center gap-1.5"><Send className="w-3 h-3" /> Ask Mode</span>
                  )}
                </button>
              ))}
              <div className="ml-auto text-[10px] text-muted-foreground self-center">
                {inputMode === "plan"
                  ? "Generates structured Plan → Approve → Execute workflow"
                  : "Direct chat with SPECTER AI"}
              </div>
            </div>
            {/* Input */}
            <div className="flex gap-3">
              <Textarea
                data-testid="input-agent-message"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                className="flex-1 bg-input border-border text-foreground text-[12px] resize-none min-h-[40px] max-h-[120px]"
                placeholder={inputMode === "plan"
                  ? "Describe what to analyze — SPECTER will generate a step-by-step plan…"
                  : "Ask SPECTER anything about the binary or firmware…"}
                rows={1}
              />
              <Button
                data-testid="button-send-message"
                onClick={handleSend}
                disabled={!input.trim() || isPending}
                className="bg-primary text-primary-foreground hover:bg-primary/90 self-end h-10 w-10 p-0 shrink-0"
              >
                {inputMode === "plan" ? <Wrench className="w-4 h-4" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
            <div className="text-[10px] text-muted-foreground mt-1.5">
              Shift+Enter for newline · HIGH/CRITICAL steps require explicit approval before execution
            </div>
          </div>
        )}
      </div>

      {/* New Session dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="bg-card border-border text-foreground max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-[13px] font-semibold">New Agent Session</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-[11px] text-muted-foreground">Session Title</Label>
              <Input data-testid="input-session-title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)}
                className="mt-1 bg-input border-border text-foreground text-[12px]" placeholder="APT28 malware analysis" autoFocus />
            </div>
            <div>
              <Label className="text-[11px] text-muted-foreground">Model</Label>
              <Select value={newModel} onValueChange={setNewModel}>
                <SelectTrigger className="mt-1 bg-input border-border text-foreground text-[12px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {MODELS.map((m) => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="text-[10px] text-muted-foreground bg-muted/20 rounded p-2.5 border border-border/50">
              <div className="font-medium text-foreground/70 mb-1">Recommended setup</div>
              <div>Pull <code className="text-primary text-[9px]">Qwen3-Coder-30B</code> for full agentic capability, or use devstral-small as the Ollama fallback.</div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setNewOpen(false)} className="border-border text-muted-foreground">Cancel</Button>
            <Button data-testid="button-create-session" size="sm" onClick={handleCreate}
              disabled={createSession.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {createSession.isPending ? "Creating..." : "Create Session"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
