import { useState } from "react";
import { useListFirmware, useAnalyzeFirmware, useApplyFirmwarePatch, useGetFirmwareSections, getListFirmwareQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Cpu, Play, AlertTriangle, CheckCircle, ChevronRight, Upload, Zap, Shield, Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { formatDistanceToNow } from "date-fns";

function RiskBadge({ level }: { level: string }) {
  const cfg: Record<string, string> = {
    critical: "risk-critical",
    high: "risk-high",
    medium: "risk-medium",
    low: "risk-low",
    unknown: "text-muted-foreground border-muted-foreground/40 bg-muted/20",
  };
  return <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-widest", cfg[level] ?? cfg.unknown)}>{level}</span>;
}

function FirmwareSections({ id }: { id: string }) {
  const { data: sections } = useGetFirmwareSections(id);
  return (
    <div className="rounded border border-border overflow-hidden mt-2">
      <table className="w-full text-[11px]">
        <thead className="bg-muted/30">
          <tr>
            {["Section", "Type", "Offset", "Size", "Entropy", "Flags"].map((h) => (
              <th key={h} className="text-left px-3 py-2 text-muted-foreground uppercase tracking-widest text-[9px]">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {sections?.map((s) => (
            <tr key={s.id} className={cn("hover:bg-muted/20 transition-colors", s.flags?.includes("CRITICAL") || s.flags?.includes("HIDDEN") ? "bg-destructive/5" : "")}>
              <td className="px-3 py-2 font-mono text-primary max-w-[180px] truncate">{s.name}</td>
              <td className="px-3 py-2 text-secondary text-[10px]">{s.sectionType}</td>
              <td className="px-3 py-2 font-mono text-muted-foreground text-[10px]">0x{s.offset.toString(16).toUpperCase().padStart(6, "0")}</td>
              <td className="px-3 py-2 text-muted-foreground">{(s.size / 1024).toFixed(0)} KB</td>
              <td className="px-3 py-2">
                <span className={cn("font-bold", (s.entropy ?? 0) > 7 ? "text-destructive" : (s.entropy ?? 0) > 5.5 ? "text-accent" : "text-primary")}>
                  {s.entropy?.toFixed(2)}
                </span>
              </td>
              <td className="px-3 py-2">
                <div className="flex gap-1 flex-wrap">
                  {s.flags?.map((f) => (
                    <span key={f} className={cn("text-[9px] px-1 py-0.5 rounded border", f === "CRITICAL" || f === "HIDDEN" || f === "UNDOCUMENTED" ? "risk-critical" : f === "SMM" ? "risk-high" : "risk-info")}>
                      {f}
                    </span>
                  ))}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PatchDialog({ firmwareId, firmwareName, onClose }: { firmwareId: string; firmwareName: string; onClose: () => void }) {
  const applyPatch = useApplyFirmwarePatch();
  const { toast } = useToast();
  const qc = useQueryClient();

  const [patchType, setPatchType] = useState("vulnerability_fix");
  const [description, setDescription] = useState("");
  const [offset, setOffset] = useState("");
  const [consent1, setConsent1] = useState(false);
  const [consent2, setConsent2] = useState(false);
  const [result, setResult] = useState<{ riskAssessment: string; reasoning: string; warnings: string[]; success: boolean } | null>(null);

  const riskColors: Record<string, string> = {
    CRITICAL: "text-destructive border-destructive/30 bg-destructive/10",
    HIGH: "text-accent border-accent/30 bg-accent/10",
    MEDIUM: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10",
  };

  const handleApply = () => {
    if (!consent1 || !consent2) return;
    applyPatch.mutate(
      {
        id: firmwareId,
        data: {
          patchType: patchType as "vulnerability_fix" | "config_patch" | "bootloader_mod" | "custom",
          description: description || `${patchType} patch`,
          targetOffset: offset ? parseInt(offset, 16) : 0,
          userConsentConfirmed: true,
          riskAcknowledged: true,
        },
      },
      {
        onSuccess: (data) => {
          setResult(data as { riskAssessment: string; reasoning: string; warnings: string[]; success: boolean });
          qc.invalidateQueries({ queryKey: getListFirmwareQueryKey() });
          toast({ title: "Patch applied", description: `Risk: ${(data as { riskAssessment: string }).riskAssessment}` });
        },
        onError: () => toast({ title: "Patch failed", variant: "destructive" }),
      }
    );
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-card border-border text-foreground max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-[13px] font-bold tracking-widest uppercase flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-destructive" /> Firmware Patch Operation
          </DialogTitle>
        </DialogHeader>
        {!result ? (
          <div className="space-y-4">
            <div className="rounded border border-destructive/30 bg-destructive/10 p-3 text-[11px] text-destructive space-y-1">
              <div className="font-bold">⚠ DANGEROUS OPERATION</div>
              <div>Firmware patching can permanently damage or brick a device. SPECTER will perform intelligent risk analysis before proceeding. Backups are mandatory.</div>
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Target Firmware</Label>
              <div className="mt-1 px-3 py-2 rounded border border-border bg-muted/20 text-[12px] font-mono text-primary">{firmwareName}</div>
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Patch Type</Label>
              <Select value={patchType} onValueChange={setPatchType}>
                <SelectTrigger data-testid="select-patch-type" className="mt-1 bg-input border-border text-foreground text-[12px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  <SelectItem value="vulnerability_fix">Vulnerability Fix</SelectItem>
                  <SelectItem value="config_patch">Configuration Patch</SelectItem>
                  <SelectItem value="bootloader_mod">Bootloader Modification (CRITICAL)</SelectItem>
                  <SelectItem value="custom">Custom Binary Patch</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Description</Label>
              <Textarea
                data-testid="input-patch-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="mt-1 bg-input border-border text-foreground text-[12px] resize-none"
                rows={2}
                placeholder="Describe what this patch does..."
              />
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Target Offset (hex, optional)</Label>
              <Input
                data-testid="input-patch-offset"
                value={offset}
                onChange={(e) => setOffset(e.target.value)}
                className="mt-1 bg-input border-border text-foreground text-[12px] font-mono"
                placeholder="0x3E8000"
              />
            </div>
            <div className="space-y-3 pt-2 border-t border-border">
              <div className="flex items-start gap-2">
                <Checkbox id="c1" checked={consent1} onCheckedChange={(v) => setConsent1(!!v)} className="mt-0.5 border-destructive data-[state=checked]:bg-destructive data-[state=checked]:border-destructive" />
                <label htmlFor="c1" className="text-[11px] text-foreground leading-relaxed cursor-pointer">
                  I understand this patch may permanently modify firmware and could brick the target device. A backup will be created but recovery is not guaranteed.
                </label>
              </div>
              <div className="flex items-start gap-2">
                <Checkbox id="c2" checked={consent2} onCheckedChange={(v) => setConsent2(!!v)} className="mt-0.5 border-destructive data-[state=checked]:bg-destructive data-[state=checked]:border-destructive" />
                <label htmlFor="c2" className="text-[11px] text-foreground leading-relaxed cursor-pointer">
                  I take full responsibility for the consequences of this operation. I have verified the target offset and patch bytes independently.
                </label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" size="sm" onClick={onClose} className="text-[11px] border-border text-muted-foreground">Cancel</Button>
              <Button
                data-testid="button-apply-patch"
                size="sm"
                onClick={handleApply}
                disabled={!consent1 || !consent2 || applyPatch.isPending}
                className="bg-destructive text-white hover:bg-destructive/90 text-[11px] uppercase tracking-wider gap-1.5"
              >
                <Zap className="w-3.5 h-3.5" /> {applyPatch.isPending ? "Applying..." : "Apply Patch"}
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-4">
            <div className={cn("rounded border p-3 space-y-1", riskColors[result.riskAssessment] ?? riskColors.MEDIUM)}>
              <div className="text-[11px] font-bold uppercase tracking-wider">Risk Assessment: {result.riskAssessment}</div>
            </div>
            <div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-2">AI Reasoning</div>
              <div className="rounded border border-border bg-muted/20 p-3 text-[11px] text-foreground leading-relaxed">{result.reasoning}</div>
            </div>
            {result.warnings?.length > 0 && (
              <div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-2">Warnings</div>
                <div className="space-y-1.5">
                  {result.warnings.map((w, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px] text-accent">
                      <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" /> {w}
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 text-[11px] text-primary">
              <CheckCircle className="w-4 h-4" /> Patch applied — backup saved
            </div>
            <DialogFooter>
              <Button size="sm" onClick={onClose} className="bg-primary text-primary-foreground text-[11px]">Close</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function Firmware() {
  const { data: firmware, isLoading } = useListFirmware({ query: { refetchInterval: 5000 } });
  const analyzeFirmware = useAnalyzeFirmware();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [selected, setSelected] = useState<string | null>(null);
  const [patching, setPatching] = useState<string | null>(null);

  const handleAnalyze = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    analyzeFirmware.mutate(
      { id, data: { extractFilesystem: true, extractKernel: true, scanNvram: true } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListFirmwareQueryKey() });
          toast({ title: "Firmware analysis started" });
        },
      }
    );
  };

  return (
    <div className="p-6 space-y-5 max-w-6xl">
      <div>
        <div className="text-[10px] text-muted-foreground uppercase mb-1">UEFI · Bootloader · Embedded</div>
        <h1 className="text-xl font-semibold text-foreground">Firmware Analysis</h1>
      </div>

      <div className="rounded border border-border bg-card/50 p-4 text-[11px] text-muted-foreground flex items-center gap-3">
        <Upload className="w-4 h-4 shrink-0 text-primary" />
        <span>Upload firmware images via the binary upload endpoint — UEFI, BIOS dumps, bootloaders, embedded Linux, raw flash images supported.</span>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-[12px]">Loading...</div>
      ) : !firmware?.length ? (
        <div className="rounded-md border border-border bg-card p-12 text-center dot-bg">
          <Cpu className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <div className="text-[13px] text-muted-foreground">No firmware uploaded yet</div>
          <div className="text-[11px] text-muted-foreground/60 mt-1">Upload UEFI dumps, BIOS images, or raw flash content</div>
        </div>
      ) : (
        <div className="space-y-2">
          {firmware.map((fw) => (
            <div key={fw.id} className="rounded border border-border bg-card overflow-hidden">
              <div
                data-testid={`card-firmware-${fw.id}`}
                className="px-4 py-3 flex items-center gap-3 cursor-pointer hover:bg-muted/20 transition-colors"
                onClick={() => setSelected(selected === fw.id ? null : fw.id)}
              >
                <Cpu className="w-4 h-4 text-secondary shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[12px] font-bold text-foreground">{fw.filename}</span>
                    <RiskBadge level={fw.riskLevel} />
                    {fw.firmwareType !== "unknown" && <span className="text-[9px] px-1.5 py-0.5 rounded border risk-info uppercase">{fw.firmwareType}</span>}
                    {fw.vendor && <span className="text-[9px] text-muted-foreground">{fw.vendor}</span>}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {(fw.fileSize / 1024 / 1024).toFixed(1)} MB
                    {fw.sectionCount ? ` · ${fw.sectionCount} sections` : ""}
                    {fw.vulnerabilityCount ? ` · ${fw.vulnerabilityCount} vulns` : ""}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {fw.analysisStatus !== "analyzing" && fw.analysisStatus !== "queued" && (
                    <>
                      <Button
                        data-testid={`button-analyze-firmware-${fw.id}`}
                        size="sm"
                        onClick={(e) => handleAnalyze(fw.id, e)}
                        className="h-7 px-3 bg-secondary/10 border border-secondary/30 text-secondary hover:bg-secondary/20 text-[10px] uppercase tracking-wider gap-1.5"
                      >
                        <Play className="w-3 h-3" /> Analyze
                      </Button>
                      {fw.analysisStatus === "complete" && (
                        <Button
                          data-testid={`button-patch-firmware-${fw.id}`}
                          size="sm"
                          onClick={(e) => { e.stopPropagation(); setPatching(fw.id); }}
                          className="h-7 px-3 bg-destructive/10 border border-destructive/30 text-destructive hover:bg-destructive/20 text-[10px] uppercase tracking-wider gap-1.5"
                        >
                          <Zap className="w-3 h-3" /> Patch
                        </Button>
                      )}
                    </>
                  )}
                  {(fw.analysisStatus === "queued" || fw.analysisStatus === "analyzing") && (
                    <div className="flex items-center gap-2 text-[10px] text-secondary">
                      <div className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" /> Analyzing...
                    </div>
                  )}
                  <ChevronRight className={cn("w-4 h-4 text-muted-foreground transition-transform", selected === fw.id ? "rotate-90" : "")} />
                </div>
              </div>
              {selected === fw.id && fw.analysisStatus === "complete" && (
                <div className="px-4 pb-4 border-t border-border">
                  <Tabs defaultValue="sections">
                    <TabsList className="mt-3 bg-muted/30 border border-border h-8">
                      <TabsTrigger value="sections" className="text-[11px] uppercase tracking-wider data-[state=active]:bg-secondary/20 data-[state=active]:text-secondary h-7 px-3">
                        Sections ({fw.sectionCount})
                      </TabsTrigger>
                    </TabsList>
                    <TabsContent value="sections">
                      <FirmwareSections id={fw.id} />
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {patching && (
        <PatchDialog
          firmwareId={patching}
          firmwareName={firmware?.find((f) => f.id === patching)?.filename ?? patching}
          onClose={() => setPatching(null)}
        />
      )}
    </div>
  );
}
