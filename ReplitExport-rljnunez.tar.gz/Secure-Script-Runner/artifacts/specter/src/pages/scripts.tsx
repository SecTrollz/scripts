import { useState } from "react";
import { useListScripts, useCreateScript, useUpdateScript, useDeleteScript, useRunScript, getListScriptsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Code2, Plus, Play, Trash2, Save, Terminal } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

const TEMPLATES: Record<string, string> = {
  "Find Crypto Constants": `# Ghidra Python — Find cryptographic constants
from ghidra.program.model.mem import MemoryAccessException

CRYPTO_CONSTANTS = [
  0x67452301, 0xEFCDAB89,  # MD5 init
  0x6A09E667, 0xBB67AE85,  # SHA-256 init
  0x9E3779B9,              # TEA/XTEA delta
  0x61C88647,              # AES Rcon
]

for block in currentProgram.memory.blocks:
    if block.isInitialized():
        for addr in range(block.start.offset, block.end.offset - 4, 4):
            try:
                val = currentProgram.memory.getInt(toAddr(addr))
                if val in CRYPTO_CONSTANTS:
                    print(f"[CRYPTO] Found constant 0x{val:08X} @ 0x{addr:X}")
                    createBookmark(toAddr(addr), "CRYPTO", f"Constant 0x{val:08X}")
            except MemoryAccessException:
                pass
print("Crypto scan complete.")`,

  "Extract All Strings": `# Ghidra Python — Extract defined strings
from ghidra.program.model.data import StringDataType

count = 0
for data in currentProgram.listing.definedData:
    dt = data.dataType
    if isinstance(dt, StringDataType) or "string" in str(dt).lower():
        s = str(data.value)
        if len(s) > 4:
            print(f"0x{data.address}: {repr(s)}")
            count += 1
print(f"Found {count} strings.")`,

  "Find Network APIs": `# Ghidra Python — Detect network-related imports
NETWORK_APIS = [
    "WSAStartup", "WSAConnect", "connect", "send", "recv",
    "getaddrinfo", "socket", "bind", "listen", "accept",
    "HttpSendRequest", "InternetOpenUrl", "WinHttpOpen",
]

for sym in currentProgram.symbolTable.allSymbols:
    name = sym.name
    if any(api.lower() in name.lower() for api in NETWORK_APIS):
        refs = sym.references
        print(f"[NET] {name} @ {sym.address} — {sum(1 for _ in refs)} xrefs")
        createBookmark(sym.address, "NETWORK", name)
print("Network API scan complete.")`,
};

export default function Scripts() {
  const { data: scripts, isLoading } = useListScripts({ query: { refetchInterval: 5000 } });
  const createScript = useCreateScript();
  const updateScript = useUpdateScript();
  const deleteScript = useDeleteScript();
  const runScript = useRunScript();
  const qc = useQueryClient();
  const { toast } = useToast();

  const [selected, setSelected] = useState<string | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [editCode, setEditCode] = useState<string>("");
  const [editName, setEditName] = useState<string>("");
  const [editDesc, setEditDesc] = useState<string>("");
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newLang, setNewLang] = useState("python");
  const [newCode, setNewCode] = useState("");
  const [template, setTemplate] = useState("");

  const selectedScript = scripts?.find((s) => s.id === selected);

  const handleSelect = (id: string) => {
    const s = scripts?.find((sc) => sc.id === id);
    if (!s) return;
    setSelected(id);
    setEditCode(s.code);
    setEditName(s.name);
    setEditDesc(s.description ?? "");
  };

  const handleSave = () => {
    if (!selected) return;
    updateScript.mutate(
      { id: selected, data: { name: editName, description: editDesc, code: editCode } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListScriptsQueryKey() });
          toast({ title: "Script saved" });
        },
      }
    );
  };

  const handleRun = () => {
    if (!selected) return;
    runScript.mutate(
      { id: selected, data: { binaryId: "placeholder", parameters: {} } },
      {
        onSuccess: () => toast({ title: "Script queued", description: "Running in Ghidra headless..." }),
      }
    );
  };

  const handleCreate = () => {
    createScript.mutate(
      { data: { name: newName, description: newDesc, language: newLang as "python" | "java" | "javascript", code: newCode || "# New Ghidra script\n", scriptType: "post" } },
      {
        onSuccess: (s) => {
          qc.invalidateQueries({ queryKey: getListScriptsQueryKey() });
          toast({ title: "Script created" });
          setNewOpen(false);
          setNewName(""); setNewDesc(""); setNewCode(""); setTemplate("");
          handleSelect(s.id);
        },
      }
    );
  };

  return (
    <div className="p-6 h-[calc(100vh-0px)] flex flex-col max-w-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[10px] text-muted-foreground uppercase mb-1">Ghidra Headless Scripting</div>
          <h1 className="text-xl font-semibold text-foreground">Script Editor</h1>
        </div>
        <Button
          data-testid="button-new-script"
          size="sm"
          onClick={() => setNewOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 text-[12px] font-medium"
        >
          <Plus className="w-3.5 h-3.5" /> New Script
        </Button>
      </div>

      <div className="flex-1 flex gap-4 min-h-0">
        {/* Script list */}
        <div className="w-56 shrink-0 flex flex-col gap-1 overflow-y-auto">
          {isLoading ? (
            <div className="text-muted-foreground text-[11px]">Loading...</div>
          ) : !scripts?.length ? (
            <div className="text-muted-foreground text-[11px] text-center py-8">No scripts yet</div>
          ) : (
            scripts.map((s) => (
              <div
                key={s.id}
                data-testid={`card-script-${s.id}`}
                onClick={() => handleSelect(s.id)}
                className={cn(
                  "rounded border px-3 py-2.5 cursor-pointer transition-all",
                  selected === s.id ? "border-primary/40 bg-primary/10 text-primary" : "border-border bg-card text-foreground hover:bg-muted/20 hover:border-border/60"
                )}
              >
                <div className="text-[11px] font-medium truncate">{s.name}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5 flex items-center justify-between">
                  <span className="uppercase">{s.language}</span>
                  <span>runs: {s.runCount}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Editor */}
        {selected && selectedScript ? (
          <div className="flex-1 flex flex-col min-h-0 rounded border border-border bg-card overflow-hidden">
            <div className="px-4 py-2.5 border-b border-border flex items-center gap-3 bg-muted/20">
              <Terminal className="w-4 h-4 text-primary" />
              <input
                data-testid="input-script-name"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="flex-1 bg-transparent text-[13px] font-bold text-foreground outline-none"
              />
              <div className="flex items-center gap-2">
                <Button
                  data-testid="button-save-script"
                  size="sm"
                  onClick={handleSave}
                  disabled={updateScript.isPending}
                  className="h-7 px-3 bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 text-[10px] uppercase tracking-wider gap-1.5"
                >
                  <Save className="w-3 h-3" /> Save
                </Button>
                <Button
                  data-testid="button-run-script"
                  size="sm"
                  onClick={handleRun}
                  disabled={runScript.isPending}
                  className="h-7 px-3 bg-secondary/10 border border-secondary/30 text-secondary hover:bg-secondary/20 text-[10px] uppercase tracking-wider gap-1.5"
                >
                  <Play className="w-3 h-3" /> Run
                </Button>
                <button
                  data-testid="button-delete-script"
                  onClick={() => {
                    if (!confirm(`Delete "${selectedScript.name}"?`)) return;
                    deleteScript.mutate({ id: selected }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListScriptsQueryKey() }); setSelected(null); toast({ title: "Deleted" }); } });
                  }}
                  className="h-7 px-2 rounded hover:bg-destructive/15 hover:text-destructive text-muted-foreground transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <textarea
              data-testid="textarea-script-code"
              value={editCode}
              onChange={(e) => setEditCode(e.target.value)}
              spellCheck={false}
              className="flex-1 bg-transparent text-[12px] text-primary/90 font-mono p-4 outline-none resize-none leading-relaxed"
              style={{ tabSize: 4 }}
            />
          </div>
        ) : (
          <div className="flex-1 rounded border border-border bg-card hex-bg flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <Code2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <div className="text-[13px]">Select a script to edit</div>
              <div className="text-[11px] mt-1 opacity-60">or create a new Ghidra script</div>
            </div>
          </div>
        )}
      </div>

      {/* New Script Dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="bg-card border-border text-foreground max-w-xl">
          <DialogHeader>
            <DialogTitle className="text-[13px] font-bold tracking-widest uppercase">New Ghidra Script</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Name</Label>
                <Input data-testid="input-new-script-name" value={newName} onChange={(e) => setNewName(e.target.value)} className="mt-1 bg-input border-border text-foreground text-[12px]" placeholder="FindCryptoKeys" autoFocus />
              </div>
              <div>
                <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Language</Label>
                <Select value={newLang} onValueChange={setNewLang}>
                  <SelectTrigger className="mt-1 bg-input border-border text-foreground text-[12px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="python">Python (Jython)</SelectItem>
                    <SelectItem value="java">Java</SelectItem>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Template</Label>
              <Select value={template} onValueChange={(v) => { setTemplate(v); setNewCode(TEMPLATES[v] ?? ""); if (!newName) setNewName(v); }}>
                <SelectTrigger className="mt-1 bg-input border-border text-foreground text-[12px]">
                  <SelectValue placeholder="Select a template..." />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {Object.keys(TEMPLATES).map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[11px] uppercase tracking-widest text-muted-foreground">Description</Label>
              <Input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="mt-1 bg-input border-border text-foreground text-[12px]" placeholder="What this script does..." />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" size="sm" onClick={() => setNewOpen(false)} className="text-[11px] border-border text-muted-foreground">Cancel</Button>
            <Button
              data-testid="button-create-script"
              size="sm"
              disabled={!newName || createScript.isPending}
              onClick={handleCreate}
              className="bg-primary text-primary-foreground hover:bg-primary/90 text-[11px] uppercase tracking-wider"
            >
              {createScript.isPending ? "Creating..." : "Create Script"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
