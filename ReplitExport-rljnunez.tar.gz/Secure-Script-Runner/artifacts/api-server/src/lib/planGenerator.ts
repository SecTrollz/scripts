/**
 * Plan generator — given a user query, produces a structured list of steps.
 * Attempts to use the active model (vLLM/Ollama). Falls back to deterministic
 * simulation based on query classification.
 */
import { routeModel, chatComplete } from "./modelRouter.js";
import type { ToolName } from "./toolExecutor.js";

export interface PlanStep {
  stepOrder: number;
  tool: ToolName;
  args: Record<string, unknown>;
  description: string;
  riskLevel: number; // 0-10
  riskLabel: "low" | "medium" | "high" | "critical";
  requiresApproval: boolean;
}

const SYSTEM_PROMPT = `You are SPECTER, an advanced reverse engineering AI. Given a user analysis request, respond with ONLY a JSON array of steps. Each step must have exactly these fields:
{
  "stepOrder": <number>,
  "tool": <one of: ghidra_import|ghidra_analyze|ghidra_script|binwalk_scan|uefi_parse|lief_parse|capstone_disasm|shell_exec|file_write|cve_lookup>,
  "args": <object with tool-specific arguments>,
  "description": <string describing what this step does>,
  "riskLevel": <0-10 integer>,
  "riskLabel": <"low"|"medium"|"high"|"critical">,
  "requiresApproval": <boolean — true if riskLevel >= 7>
}
Output ONLY the JSON array, no markdown, no explanation.`;

function riskLabel(level: number): "low" | "medium" | "high" | "critical" {
  if (level >= 9) return "critical";
  if (level >= 7) return "high";
  if (level >= 4) return "medium";
  return "low";
}

function classifyQuery(query: string): string {
  const q = query.toLowerCase();
  if (q.includes("firmware") || q.includes("uefi") || q.includes("bios")) return "firmware";
  if (q.includes("network") || q.includes("c2") || q.includes("socket") || q.includes("http")) return "network";
  if (q.includes("patch") || q.includes("fix") || q.includes("write") || q.includes("modif")) return "patch";
  if (q.includes("cve") || q.includes("vuln") || q.includes("exploit")) return "vuln";
  if (q.includes("string") || q.includes("extract")) return "strings";
  if (q.includes("crypto") || q.includes("encrypt") || q.includes("aes") || q.includes("key")) return "crypto";
  if (q.includes("anti-debug") || q.includes("antidebug") || q.includes("obfuscat")) return "antidebug";
  if (q.includes("decompil") || q.includes("disasm") || q.includes("function")) return "decompile";
  return "general";
}

function simulatePlan(query: string): PlanStep[] {
  const type = classifyQuery(query);
  const proj = "specter_auto";

  const base: PlanStep[] = [
    { stepOrder: 1, tool: "ghidra_import", args: { binary_path: "target.bin", project: proj }, description: "Import binary into Ghidra project workspace", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    { stepOrder: 2, tool: "ghidra_analyze", args: { project: proj, binary: "target.bin" }, description: "Run Ghidra headless auto-analysis — function detection, xref graph, type recovery", riskLevel: 1, riskLabel: "low", requiresApproval: false },
  ];

  const steps: Record<string, PlanStep[]> = {
    firmware: [
      { stepOrder: 3, tool: "binwalk_scan", args: { firmware_path: "firmware.bin" }, description: "Scan firmware with binwalk — extract section map and entropy profile", riskLevel: 2, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "uefi_parse", args: { firmware_path: "firmware.bin" }, description: "Parse UEFI volume tree — enumerate modules, detect SMM drivers, flag dangerous mappings", riskLevel: 2, riskLabel: "low", requiresApproval: false },
      { stepOrder: 5, tool: "cve_lookup", args: { keyword: "UEFI SMM firmware vulnerability" }, description: "Query CVE database for relevant firmware vulnerabilities", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
    network: [
      { stepOrder: 3, tool: "lief_parse", args: { binary_path: "target.bin" }, description: "Parse PE/ELF structure — extract import table, identify network-related DLLs", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "ghidra_script", args: { script_path: "FindNetworkAPIs.py", args: {} }, description: "Run Ghidra script to locate all network API call sites and extract xrefs", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 5, tool: "cve_lookup", args: { keyword: "C2 network evasion malware" }, description: "Correlate network patterns with known C2 techniques via CVE lookup", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
    crypto: [
      { stepOrder: 3, tool: "ghidra_script", args: { script_path: "FindCryptoConstants.py", args: {} }, description: "Scan binary for known cryptographic constants (AES, MD5, SHA-256, TEA, RC4)", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "capstone_disasm", args: { arch: "x86_64" }, description: "Disassemble suspicious crypto-adjacent code blocks for manual review", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
    antidebug: [
      { stepOrder: 3, tool: "lief_parse", args: { binary_path: "target.bin" }, description: "Parse binary for import anomalies — flag anti-debug imports (IsDebuggerPresent, FindWindow, etc.)", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "capstone_disasm", args: { arch: "x86_64", hint: "anti-debug" }, description: "Disassemble identified anti-debug sequences — locate bypass points", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 5, tool: "ghidra_script", args: { script_path: "MapAntiDebug.py", args: {} }, description: "Map all anti-debug call sites and generate bypass patch targets", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
    strings: [
      { stepOrder: 3, tool: "ghidra_script", args: { script_path: "ExtractAllStrings.py", args: { minLen: 4 } }, description: "Extract all defined strings from binary with addresses — classify by type (URLs, IPs, paths)", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
    patch: [
      { stepOrder: 3, tool: "lief_parse", args: { binary_path: "target.bin" }, description: "Parse binary structure to identify patch target offset and validate surrounding code", riskLevel: 2, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "capstone_disasm", args: { arch: "x86_64" }, description: "Disassemble patch region to confirm target and assess side effects", riskLevel: 2, riskLabel: "low", requiresApproval: false },
      { stepOrder: 5, tool: "file_write", args: { path: "target_patched.bin", content: "[patch bytes]" }, description: "Apply patch bytes at target offset — backup created automatically before write", riskLevel: 8, riskLabel: "high", requiresApproval: true },
    ],
    vuln: [
      { stepOrder: 3, tool: "lief_parse", args: { binary_path: "target.bin" }, description: "Parse binary structure and security mitigations (ASLR, DEP, CFG, stack canary)", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "cve_lookup", args: { keyword: query.slice(0, 60) }, description: "Query NVD CVE database for vulnerabilities matching analysis context", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 5, tool: "ghidra_script", args: { script_path: "VulnPatternScan.py", args: {} }, description: "Run vulnerability pattern scanner (use-after-free, stack overflows, format strings)", riskLevel: 2, riskLabel: "low", requiresApproval: false },
    ],
    decompile: [
      { stepOrder: 3, tool: "ghidra_script", args: { script_path: "DecompileAll.py", args: {} }, description: "Decompile identified functions to C pseudocode via Ghidra decompiler API", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "capstone_disasm", args: { arch: "x86_64" }, description: "Disassemble complex function bodies where decompiler output is ambiguous", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
    general: [
      { stepOrder: 3, tool: "lief_parse", args: { binary_path: "target.bin" }, description: "Parse binary format, headers, imports, and security mitigations", riskLevel: 1, riskLabel: "low", requiresApproval: false },
      { stepOrder: 4, tool: "ghidra_script", args: { script_path: "ExtractAllStrings.py", args: {} }, description: "Extract strings from all sections for IOC and pattern analysis", riskLevel: 1, riskLabel: "low", requiresApproval: false },
    ],
  };

  return [...base, ...(steps[type] ?? steps.general)];
}

export async function generatePlan(query: string): Promise<{ steps: PlanStep[]; runtime: string; model: string }> {
  const route = await routeModel("plan");

  if (route.runtime !== "simulation") {
    try {
      const raw = await chatComplete(route, [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: query },
      ], { maxTokens: 1024, temperature: 0.1 });

      // Extract JSON array from response
      const match = raw.match(/\[[\s\S]*\]/);
      if (match) {
        const parsed = JSON.parse(match[0]) as PlanStep[];
        // Validate and normalize
        const steps = parsed.map((s, i) => ({
          ...s,
          stepOrder: i + 1,
          riskLevel: Math.max(0, Math.min(10, Number(s.riskLevel) || 0)),
          riskLabel: riskLabel(Number(s.riskLevel) || 0),
          requiresApproval: (Number(s.riskLevel) || 0) >= 7,
        }));
        return { steps, runtime: route.runtime, model: route.model };
      }
    } catch {
      // fall through to simulation
    }
  }

  const steps = simulatePlan(query);
  return { steps, runtime: route.runtime, model: route.model };
}

/** After all steps complete, generate a reflection / summary message. */
export async function generateReflection(query: string, stepOutputs: string[]): Promise<string> {
  const route = await routeModel("vuln_reason");

  const combinedOutput = stepOutputs.join("\n\n---\n\n");

  if (route.runtime !== "simulation") {
    try {
      const response = await chatComplete(route, [
        { role: "system", content: "You are SPECTER reverse engineering AI. Synthesize the following tool outputs into a structured analysis report with findings, risk assessment, and actionable recommendations. Be concise and technical." },
        { role: "user", content: `Query: ${query}\n\nTool outputs:\n${combinedOutput}` },
      ], { maxTokens: 800 });
      if (response) return response;
    } catch {
      // fall through
    }
  }

  // Simulated reflection
  return `**Analysis Complete**\n\n**Query:** ${query}\n\n**Findings from ${stepOutputs.length} tool steps:**\n\n${stepOutputs.slice(0, 3).map((o, i) => `**Step ${i + 1}:** ${o.split("\n")[0]}`).join("\n")}\n\n**Risk Summary:** Tool chain executed successfully. Identified key indicators for further investigation. All findings logged to session for audit chain of custody.\n\n**Recommendation:** Review flagged addresses in Ghidra and cross-reference with CVE findings above. Prioritise CRITICAL and HIGH items.`;
}
