/**
 * Model router: tries vLLM at :8000 first, falls back to Ollama at :11434.
 * Returns { runtime, model, baseUrl } — callers use baseUrl to make completions.
 */

export type Runtime = "vllm" | "ollama" | "simulation";

export interface RouterResult {
  runtime: Runtime;
  model: string;
  baseUrl: string;
}

const VLLM_URL = "http://localhost:8000";
const OLLAMA_URL = "http://localhost:11434";

const TASK_MODEL_MAP: Record<string, { vllm: string; ollama: string }> = {
  plan:              { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "qwen3:8b" },
  decompile:         { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "devstral-small" },
  firmware_analysis: { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "devstral-small" },
  vuln_reason:       { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "devstral-small" },
  string_search:     { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "qwen3:8b" },
  quick_lookup:      { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "qwen3:8b" },
  triage:            { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "qwen3:8b" },
  default:           { vllm: "Qwen/Qwen3-Coder-30B-A3B-Instruct", ollama: "devstral-small" },
};

let _vllmAvailable: boolean | null = null;
let _ollamaAvailable: boolean | null = null;
let _lastCheck = 0;
const CHECK_TTL = 15_000; // re-check every 15 s

async function checkVllm(): Promise<boolean> {
  try {
    const res = await fetch(`${VLLM_URL}/health`, { signal: AbortSignal.timeout(2000) });
    return res.ok;
  } catch {
    return false;
  }
}

async function checkOllama(): Promise<boolean> {
  try {
    const res = await fetch(`${OLLAMA_URL}/api/tags`, { signal: AbortSignal.timeout(2000) });
    return res.ok;
  } catch {
    return false;
  }
}

async function refreshRuntimeAvailability(): Promise<void> {
  const now = Date.now();
  if (now - _lastCheck < CHECK_TTL) return;
  _lastCheck = now;
  [_vllmAvailable, _ollamaAvailable] = await Promise.all([checkVllm(), checkOllama()]);
}

export async function routeModel(taskType = "default"): Promise<RouterResult> {
  await refreshRuntimeAvailability();
  const models = TASK_MODEL_MAP[taskType] ?? TASK_MODEL_MAP.default;

  if (_vllmAvailable) {
    return { runtime: "vllm", model: models.vllm, baseUrl: VLLM_URL };
  }
  if (_ollamaAvailable) {
    return { runtime: "ollama", model: models.ollama, baseUrl: OLLAMA_URL };
  }
  return { runtime: "simulation", model: "specter-sim-1.0", baseUrl: "" };
}

export async function getRuntimeStatus(): Promise<{ vllm: boolean; ollama: boolean; active: Runtime }> {
  await refreshRuntimeAvailability();
  const active: Runtime = _vllmAvailable ? "vllm" : _ollamaAvailable ? "ollama" : "simulation";
  return { vllm: !!_vllmAvailable, ollama: !!_ollamaAvailable, active };
}

/** Call OpenAI-compatible chat completion. Works for both vLLM and Ollama (which has /v1 compat). */
export async function chatComplete(
  route: RouterResult,
  messages: { role: string; content: string }[],
  options: { maxTokens?: number; temperature?: number } = {}
): Promise<string> {
  if (route.runtime === "simulation") throw new Error("no_model");

  const endpoint = route.runtime === "vllm"
    ? `${route.baseUrl}/v1/chat/completions`
    : `${route.baseUrl}/v1/chat/completions`;

  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: route.model,
      messages,
      max_tokens: options.maxTokens ?? 1024,
      temperature: options.temperature ?? 0.2,
      stream: false,
    }),
    signal: AbortSignal.timeout(45_000),
  });

  if (!res.ok) throw new Error(`model_error: ${res.status}`);
  const data = await res.json() as { choices?: { message?: { content?: string } }[] };
  return data.choices?.[0]?.message?.content ?? "";
}
