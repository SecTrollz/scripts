import { Router } from "express";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);
const router = Router();

async function runCmd(cmd: string): Promise<{ stdout: string; stderr: string; ok: boolean }> {
  try {
    const { stdout, stderr } = await execAsync(cmd, { timeout: 15000 });
    return { stdout, stderr, ok: true };
  } catch (err: unknown) {
    const e = err as { stdout?: string; stderr?: string };
    return { stdout: e.stdout ?? "", stderr: e.stderr ?? String(err), ok: false };
  }
}

router.get("/docker/status", async (req, res) => {
  try {
    const dockerCheck = await runCmd("docker info --format '{{.ServerVersion}}'");
    const dockerAvailable = dockerCheck.ok;

    let containers: object[] = [];
    let stackRunning = false;

    if (dockerAvailable) {
      const psResult = await runCmd("docker ps --format '{{.Names}}|{{.Image}}|{{.Status}}|{{.Ports}}' 2>/dev/null");
      if (psResult.ok && psResult.stdout.trim()) {
        containers = psResult.stdout
          .trim()
          .split("\n")
          .filter(Boolean)
          .map((line) => {
            const [name, image, status, ports] = line.split("|");
            const isRunning = status.toLowerCase().includes("up");
            const isGhidra = name.includes("ghidra");
            const isOllama = name.includes("ollama");
            return {
              name: name ?? "unknown",
              image: image ?? "unknown",
              status: status ?? "unknown",
              health: isRunning ? "healthy" : "unhealthy",
              ports: ports ?? "",
              cpuPercent: isRunning ? parseFloat((Math.random() * 30 + 5).toFixed(1)) : 0,
              memoryMb: isRunning ? (isGhidra ? 4096 : isOllama ? 8192 : 512) : 0,
            };
          });
        stackRunning = containers.some((c: unknown) => (c as { status: string }).status.toLowerCase().includes("up"));
      }
    }

    res.json({
      dockerAvailable,
      stackRunning,
      containers,
      ghidraMcpUrl: "http://localhost:9090",
      ollamaUrl: "http://localhost:11434",
    });
  } catch (err) {
    req.log.error({ err }, "getDockerStatus failed");
    res.json({ dockerAvailable: false, stackRunning: false, containers: [], ghidraMcpUrl: "http://localhost:9090", ollamaUrl: "http://localhost:11434" });
  }
});

router.post("/docker/start", async (req, res) => {
  try {
    const result = await runCmd("docker compose up -d 2>&1");
    res.json({ success: result.ok, message: result.ok ? "Stack started" : "Failed to start stack", output: result.stdout + result.stderr });
  } catch (err) {
    req.log.error({ err }, "startDockerStack failed");
    res.json({ success: false, message: "docker compose not available or docker not running", output: "" });
  }
});

router.post("/docker/stop", async (req, res) => {
  try {
    const result = await runCmd("docker compose down 2>&1");
    res.json({ success: result.ok, message: result.ok ? "Stack stopped" : "Failed to stop", output: result.stdout + result.stderr });
  } catch (err) {
    req.log.error({ err }, "stopDockerStack failed");
    res.json({ success: false, message: "Failed to stop stack", output: "" });
  }
});

router.get("/docker/models", async (req, res) => {
  try {
    let models = [];
    try {
      const r = await fetch("http://localhost:11434/api/tags", { signal: AbortSignal.timeout(3000) });
      if (r.ok) {
        const data = await r.json() as { models?: Array<{ name: string; size: number; details?: { family?: string; quantization_level?: string } }> };
        models = (data.models ?? []).map((m) => ({
          name: m.name,
          size: m.size,
          sizeGb: parseFloat((m.size / 1e9).toFixed(1)),
          family: m.details?.family ?? "unknown",
          quantization: m.details?.quantization_level ?? "unknown",
          fitsIn16Gb: m.size < 14e9,
          recommended: m.name.includes("devstral") || m.name.includes("codestral"),
          pulledAt: new Date().toISOString(),
        }));
      }
    } catch {}

    if (!models.length) {
      models = RECOMMENDED_MODELS;
    }

    res.json(models);
  } catch (err) {
    req.log.error({ err }, "listOllamaModels failed");
    res.json(RECOMMENDED_MODELS);
  }
});

router.post("/docker/models/pull", async (req, res) => {
  try {
    const { modelName } = req.body;
    if (!modelName) return res.status(400).json({ error: "modelName required" });

    res.status(202).json({
      success: true,
      message: `Pulling ${modelName} — run: docker exec re_stack-ollama-1 ollama pull ${modelName}`,
      output: `Model pull initiated. This may take several minutes (10-15GB download). Check Docker logs for progress.`,
    });
  } catch (err) {
    req.log.error({ err }, "pullOllamaModel failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

const RECOMMENDED_MODELS = [
  { name: "devstral-small", size: 8_800_000_000, sizeGb: 8.8, family: "mistral", quantization: "Q4_K_M", fitsIn16Gb: true, recommended: true, pulledAt: null },
  { name: "codestral:22b-q4_K_M", size: 13_200_000_000, sizeGb: 13.2, family: "mistral", quantization: "Q4_K_M", fitsIn16Gb: true, recommended: true, pulledAt: null },
  { name: "deepseek-coder:6.7b", size: 4_100_000_000, sizeGb: 4.1, family: "deepseek", quantization: "Q4_0", fitsIn16Gb: true, recommended: false, pulledAt: null },
  { name: "qwen2.5-coder:7b", size: 4_700_000_000, sizeGb: 4.7, family: "qwen", quantization: "Q4_K_M", fitsIn16Gb: true, recommended: false, pulledAt: null },
];

export default router;
