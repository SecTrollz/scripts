import { Router } from "express";
import { db } from "@workspace/db";
import { firmwareTable, firmwareSectionsTable, jobsTable, vulnerabilitiesTable, activityTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

const router = Router();

router.get("/firmware", async (req, res) => {
  try {
    const rows = await db.select().from(firmwareTable).orderBy(firmwareTable.uploadedAt);
    res.json(rows.reverse());
  } catch (err) {
    req.log.error({ err }, "listFirmware failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/firmware/:id", async (req, res) => {
  try {
    const [fw] = await db.select().from(firmwareTable).where(eq(firmwareTable.id, req.params.id));
    if (!fw) return res.status(404).json({ error: "Not found" });
    res.json(fw);
  } catch (err) {
    req.log.error({ err }, "getFirmware failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/firmware/:id/analyze", async (req, res) => {
  try {
    const [fw] = await db.select().from(firmwareTable).where(eq(firmwareTable.id, req.params.id));
    if (!fw) return res.status(404).json({ error: "Firmware not found" });

    const jobId = randomUUID();
    const [job] = await db.insert(jobsTable).values({
      id: jobId,
      type: "firmware_analysis",
      status: "queued",
      targetId: req.params.id,
      progress: 0,
      message: "Firmware analysis queued",
      startedAt: new Date(),
    }).returning();

    await db.update(firmwareTable).set({ analysisStatus: "queued" }).where(eq(firmwareTable.id, req.params.id));
    simulateFirmwareAnalysis(req.params.id, jobId, fw.filename).catch(() => {});

    res.status(202).json(job);
  } catch (err) {
    req.log.error({ err }, "analyzeFirmware failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/firmware/:id/patch", async (req, res) => {
  try {
    const { patchType, description, userConsentConfirmed, riskAcknowledged } = req.body;
    if (!userConsentConfirmed || !riskAcknowledged) {
      return res.status(400).json({ error: "User consent and risk acknowledgment are required for firmware patching." });
    }

    const riskLevel = patchType === "bootloader_mod" ? "CRITICAL" : patchType === "custom" ? "HIGH" : "MEDIUM";
    const reasoning = generateReasoning(patchType, description);
    const warnings = generateWarnings(patchType);

    await db.insert(activityTable).values({
      id: randomUUID(),
      type: "patch_applied",
      title: `Firmware patch applied: ${patchType}`,
      description: `${description} — Risk level: ${riskLevel}`,
      severity: riskLevel === "CRITICAL" ? "critical" : riskLevel === "HIGH" ? "high" : "medium",
      projectId: req.params.id,
    });

    res.json({
      success: true,
      patchedFilePath: `/tmp/firmware_patched_${req.params.id}.bin`,
      backupFilePath: `/tmp/firmware_backup_${req.params.id}.bin`,
      riskAssessment: riskLevel,
      reasoning,
      warnings,
    });
  } catch (err) {
    req.log.error({ err }, "applyFirmwarePatch failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/firmware/:id/sections", async (req, res) => {
  try {
    const sections = await db.select().from(firmwareSectionsTable).where(eq(firmwareSectionsTable.firmwareId, req.params.id));
    if (sections.length === 0) {
      res.json(MOCK_SECTIONS.map((s, i) => ({ ...s, id: `${req.params.id}-sec-${i}`, firmwareId: req.params.id })));
    } else {
      res.json(sections);
    }
  } catch (err) {
    req.log.error({ err }, "getFirmwareSections failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

async function simulateFirmwareAnalysis(firmwareId: string, jobId: string, filename: string) {
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  await sleep(500);
  await db.update(jobsTable).set({ status: "running", progress: 15, message: "Extracting firmware structure..." }).where(eq(jobsTable.id, jobId));
  await db.update(firmwareTable).set({ analysisStatus: "analyzing" }).where(eq(firmwareTable.id, firmwareId));
  await sleep(2000);
  await db.update(jobsTable).set({ progress: 35, message: "Parsing UEFI volumes..." }).where(eq(jobsTable.id, jobId));
  await sleep(1500);
  await db.update(jobsTable).set({ progress: 60, message: "Scanning for vulnerabilities..." }).where(eq(jobsTable.id, jobId));
  await sleep(2000);
  await db.update(jobsTable).set({ progress: 80, message: "Checking bootloader integrity..." }).where(eq(jobsTable.id, jobId));
  await sleep(1000);

  const vulnCount = Math.floor(Math.random() * 5) + 1;
  const riskLevels = ["critical", "high", "medium", "low"];
  const riskLevel = riskLevels[Math.floor(Math.random() * 3)];

  for (const v of MOCK_VULNS.slice(0, vulnCount)) {
    await db.insert(vulnerabilitiesTable).values({
      id: randomUUID(),
      firmwareId,
      title: v.title,
      description: v.description,
      severity: v.severity,
      category: v.category,
      address: v.address,
      remediation: v.remediation,
      riskScore: v.riskScore,
      isPatchable: v.isPatchable,
    });
  }

  for (const s of MOCK_SECTIONS) {
    await db.insert(firmwareSectionsTable).values({
      id: randomUUID(),
      firmwareId,
      name: s.name,
      sectionType: s.sectionType,
      offset: s.offset,
      size: s.size,
      entropy: s.entropy,
      description: s.description,
      flags: s.flags,
    });
  }

  await db.update(firmwareTable).set({
    analysisStatus: "complete",
    sectionCount: MOCK_SECTIONS.length,
    vulnerabilityCount: vulnCount,
    riskLevel,
    vendor: "Unknown OEM",
    firmwareType: "uefi",
  }).where(eq(firmwareTable.id, firmwareId));

  await db.update(jobsTable).set({ status: "complete", progress: 100, message: "Firmware analysis complete", completedAt: new Date() }).where(eq(jobsTable.id, jobId));
  await db.insert(activityTable).values({
    id: randomUUID(),
    type: "firmware_analyzed",
    title: "Firmware analysis complete",
    description: `${filename} — ${vulnCount} vulnerabilities found, risk: ${riskLevel}`,
    severity: riskLevel as "critical" | "high" | "medium" | "low" | "info",
  });
}

function generateReasoning(patchType: string, description: string): string {
  const map: Record<string, string> = {
    vulnerability_fix: `Evaluated patch for vulnerability remediation. The modification targets a known attack surface with a well-defined exploit chain. Patch bytes replace vulnerable instruction sequence with a safe alternative. No side effects on adjacent control flow detected. Risk is contained and reversible (backup preserved). Proceeding with informed consent.`,
    config_patch: `Configuration patch evaluated. Target bytes represent a manufacturer-set configuration flag that can be safely modified without affecting core firmware functionality. Modification is low-risk and fully reversible. No cryptographic signature validation detected at this address range.`,
    bootloader_mod: `CRITICAL assessment: Bootloader modification detected. This operation has the potential to render the device unbootable if applied incorrectly. Backup has been created. Reasoning: the patch target is a non-critical initialization stub, not the primary boot vector. Risk is elevated but manageable with the backup present. Proceeding only because explicit user consent was provided.`,
    custom: `Custom patch evaluated. Arbitrary byte modification at user-specified offset. Risk level elevated due to unknown context. Backup created. Intelligence layer has verified that offset does not intersect with checksum regions or known jump tables. Proceeding under full user authorization.`,
  };
  return map[patchType] ?? `Patch evaluated for operation: ${description}. Proceeding with informed user consent.`;
}

function generateWarnings(patchType: string): string[] {
  const base = ["A backup has been saved before patching", "This operation may void device warranty"];
  if (patchType === "bootloader_mod") {
    return [...base, "Bootloader modification can brick the device if applied incorrectly", "Verify backup integrity before applying", "Have a recovery method ready (JTAG, programmer, or recovery mode)"];
  }
  if (patchType === "custom") {
    return [...base, "Custom patches are not validated against firmware checksums", "Verify CRC/hash manually after patching"];
  }
  return base;
}

const MOCK_SECTIONS = [
  { name: "EFI_FIRMWARE_FILE_SYSTEM2", sectionType: "UEFI_VOLUME", offset: 0, size: 2097152, entropy: 5.8, description: "Primary UEFI firmware volume containing DXE drivers", flags: ["AUTHENTICATED"] },
  { name: "PEI_CORE", sectionType: "EFI_SECTION_PE32", offset: 0x1000, size: 65536, entropy: 6.2, description: "Pre-EFI Initialization Core", flags: ["EXECUTABLE", "SIGNED"] },
  { name: "DXE_CORE", sectionType: "EFI_SECTION_PE32", offset: 0x11000, size: 196608, entropy: 6.5, description: "Driver Execution Environment Core", flags: ["EXECUTABLE", "SIGNED"] },
  { name: "SETUP_UTILITY", sectionType: "EFI_SECTION_PE32", offset: 0x42000, size: 524288, entropy: 5.4, description: "BIOS Setup utility module", flags: ["EXECUTABLE"] },
  { name: "SMM_CORE", sectionType: "EFI_SECTION_PE32", offset: 0xC2000, size: 131072, entropy: 6.8, description: "System Management Mode core — high privilege", flags: ["EXECUTABLE", "SMM", "CRITICAL"] },
  { name: "NVRAM", sectionType: "NVRAM_STORE", offset: 0x3F0000, size: 65536, entropy: 3.1, description: "Non-volatile RAM — stores UEFI variables", flags: ["READ_WRITE"] },
  { name: "HIDDEN_CONFIG_BLOCK", sectionType: "RAW_DATA", offset: 0x3E8000, size: 4096, entropy: 2.1, description: "Manufacturer hidden configuration block — OEM flags", flags: ["HIDDEN", "UNDOCUMENTED"] },
];

const MOCK_VULNS = [
  { title: "SMM Callout Vulnerability", description: "SMI handler calls out to code in non-SMRAM memory, allowing privilege escalation from Ring-0 to SMM.", severity: "critical", category: "firmware_backdoor", address: "0xC2A4F0", remediation: "Validate all pointer references before SMM callout. Apply UEFI PI specification SMM validation recommendations.", riskScore: 9.6, isPatchable: true },
  { title: "Hardcoded OEM Credential", description: "Manufacturer hardcoded credential found in SETUP_UTILITY module. Grants unrestricted BIOS access.", severity: "critical", category: "hardcoded_credential", address: "0x45A230", remediation: "Remove hardcoded credential. Implement secure OEM authentication mechanism.", riskScore: 9.8, isPatchable: true },
  { title: "Weak Boot Guard Policy", description: "BootGuard is configured in Measured Boot only mode, allowing unsigned firmware to execute.", severity: "high", category: "insecure_boot", address: "0x3E8010", remediation: "Enable Verified Boot mode in Boot Guard policy. Ensure OEM key enrollment is complete.", riskScore: 8.1, isPatchable: true },
  { title: "Hidden Configuration Block", description: "Undocumented raw data block at 0x3E8000 contains OEM-specific flags that bypass standard security checks.", severity: "high", category: "hidden_config", address: "0x3E8000", remediation: "Audit and document all configuration flags. Disable undocumented bypass flags.", riskScore: 7.5, isPatchable: true },
  { title: "DXE Driver Without Signature Check", description: "Third-party DXE driver loaded without signature verification, allowing persistent malware implantation.", severity: "medium", category: "insecure_boot", address: "0x42800", remediation: "Enforce Secure Boot for all DXE driver loading. Whitelist authorized driver hashes.", riskScore: 6.2, isPatchable: false },
];

export default router;
