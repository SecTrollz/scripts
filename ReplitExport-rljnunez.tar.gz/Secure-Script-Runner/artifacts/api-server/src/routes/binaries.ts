import { Router } from "express";
import { db } from "@workspace/db";
import {
  binariesTable,
  jobsTable,
  activityTable,
  projectsTable,
} from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { randomUUID } from "crypto";
import { AnalyzeBinaryBody } from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router = Router();

router.get("/binaries", async (req, res) => {
  try {
    const { projectId } = req.query;
    const rows = projectId
      ? await db.select().from(binariesTable).where(eq(binariesTable.projectId, String(projectId)))
      : await db.select().from(binariesTable);
    res.json(rows.reverse());
  } catch (err) {
    req.log.error({ err }, "listBinaries failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/binaries/:id", async (req, res) => {
  try {
    const [bin] = await db.select().from(binariesTable).where(eq(binariesTable.id, req.params.id));
    if (!bin) return res.status(404).json({ error: "Not found" });
    res.json(bin);
  } catch (err) {
    req.log.error({ err }, "getBinary failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/binaries/:id", async (req, res) => {
  try {
    await db.delete(binariesTable).where(eq(binariesTable.id, req.params.id));
    res.status(204).end();
  } catch (err) {
    req.log.error({ err }, "deleteBinary failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/binaries/:id/analyze", async (req, res) => {
  try {
    const [bin] = await db.select().from(binariesTable).where(eq(binariesTable.id, req.params.id));
    if (!bin) return res.status(404).json({ error: "Binary not found" });

    const jobId = randomUUID();
    const [job] = await db
      .insert(jobsTable)
      .values({
        id: jobId,
        type: "binary_analysis",
        status: "queued",
        targetId: req.params.id,
        progress: 0,
        message: "Analysis queued",
        startedAt: new Date(),
      })
      .returning();

    await db
      .update(binariesTable)
      .set({ analysisStatus: "queued" })
      .where(eq(binariesTable.id, req.params.id));

    simulateAnalysis(req.params.id, jobId, bin.filename).catch(() => {});

    res.status(202).json(job);
  } catch (err) {
    req.log.error({ err }, "analyzeBinary failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

async function simulateAnalysis(binaryId: string, jobId: string, filename: string) {
  await sleep(500);
  await db.update(jobsTable).set({ status: "running", progress: 10, message: "Importing binary into Ghidra project..." }).where(eq(jobsTable.id, jobId));
  await db.update(binariesTable).set({ analysisStatus: "analyzing" }).where(eq(binariesTable.id, binaryId));
  await sleep(2000);
  await db.update(jobsTable).set({ progress: 40, message: "Running auto-analysis..." }).where(eq(jobsTable.id, jobId));
  await sleep(2000);
  await db.update(jobsTable).set({ progress: 70, message: "Extracting functions and strings..." }).where(eq(jobsTable.id, jobId));
  await sleep(1500);
  const funcs = Math.floor(Math.random() * 400) + 50;
  const strings = Math.floor(Math.random() * 2000) + 100;
  const imports = Math.floor(Math.random() * 80) + 10;
  const entropy = parseFloat((Math.random() * 2 + 5.5).toFixed(2));
  await db.update(binariesTable).set({
    analysisStatus: "complete",
    functionCount: funcs,
    stringCount: strings,
    importCount: imports,
    entropyScore: entropy,
    analyzedAt: new Date(),
    architecture: pickRandom(["x86_64", "x86", "ARM64", "ARM32", "MIPS"]),
    fileType: pickRandom(["PE32+", "PE32", "ELF64", "ELF32", "Mach-O"]),
  }).where(eq(binariesTable.id, binaryId));
  await db.update(jobsTable).set({ status: "complete", progress: 100, message: "Analysis complete", completedAt: new Date() }).where(eq(jobsTable.id, jobId));
  await db.insert(activityTable).values({
    id: randomUUID(),
    type: "analysis_complete",
    title: "Binary analysis complete",
    description: `${filename} — ${funcs} functions, ${strings} strings, ${imports} imports`,
    severity: "info",
  });
}

router.get("/binaries/:id/functions", async (req, res) => {
  const { id } = req.params;
  const funcs = MOCK_FUNCTIONS.map((f, i) => ({ ...f, id: `${id}-fn-${i}`, binaryId: id }));
  res.json(funcs);
});

router.get("/binaries/:id/strings", async (req, res) => {
  const { id } = req.params;
  const strings = MOCK_STRINGS.map((s, i) => ({ ...s, id: `${id}-str-${i}`, binaryId: id }));
  res.json(strings);
});

router.get("/jobs/:id", async (req, res) => {
  try {
    const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, req.params.id));
    if (!job) return res.status(404).json({ error: "Job not found" });
    res.json(job);
  } catch (err) {
    req.log.error({ err }, "getJob failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

const MOCK_FUNCTIONS = [
  { name: "main", address: "0x00401000", size: 512, calledBy: [], calls: ["sub_401200", "WSAStartup"], riskScore: 2.1, tags: ["entry"] },
  { name: "WSAConnect", address: "0x00401200", size: 256, calledBy: ["main"], calls: ["getaddrinfo"], riskScore: 7.8, tags: ["network", "suspicious"] },
  { name: "CryptDecrypt", address: "0x004015A0", size: 180, calledBy: ["main"], calls: [], riskScore: 8.5, tags: ["crypto", "high-risk"] },
  { name: "CreateRemoteThread", address: "0x00401800", size: 320, calledBy: ["main"], calls: ["VirtualAllocEx"], riskScore: 9.2, tags: ["injection", "critical"] },
  { name: "RegOpenKeyEx", address: "0x00401C00", size: 140, calledBy: ["main"], calls: [], riskScore: 6.4, tags: ["registry", "persistence"] },
  { name: "sub_401E00", address: "0x00401E00", size: 88, calledBy: ["main"], calls: [], riskScore: 1.2, tags: [] },
  { name: "decrypt_string", address: "0x004020F0", size: 204, calledBy: ["main", "sub_401E00"], calls: ["CryptDecrypt"], riskScore: 8.1, tags: ["crypto", "obfuscation"] },
  { name: "init_c2", address: "0x00402400", size: 460, calledBy: ["main"], calls: ["WSAConnect", "send", "recv"], riskScore: 9.7, tags: ["c2", "network", "critical"] },
];

const MOCK_STRINGS = [
  { value: "http://malicious-update.net/payload", address: "0x004A1234", encoding: "UTF-8", length: 36 },
  { value: "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", address: "0x004A1290", encoding: "UTF-8", length: 44 },
  { value: "cmd.exe /c powershell -enc", address: "0x004A12F0", encoding: "UTF-8", length: 26 },
  { value: "Mozilla/5.0 (Windows NT 10.0)", address: "0x004A1350", encoding: "UTF-8", length: 29 },
  { value: "AES-256-CBC", address: "0x004A1390", encoding: "UTF-8", length: 11 },
  { value: "\\pipe\\ntsvcs", address: "0x004A13C0", encoding: "UTF-8", length: 12 },
];

export default router;
