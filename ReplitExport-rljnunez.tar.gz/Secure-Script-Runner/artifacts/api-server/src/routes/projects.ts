import { Router } from "express";
import { db } from "@workspace/db";
import { projectsTable, activityTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { CreateProjectBody } from "@workspace/api-zod";

const router = Router();

router.get("/projects", async (req, res) => {
  try {
    const projects = await db.select().from(projectsTable).orderBy(projectsTable.createdAt);
    res.json(projects.reverse());
  } catch (err) {
    req.log.error({ err }, "listProjects failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/projects", async (req, res) => {
  try {
    const body = CreateProjectBody.parse(req.body);
    const id = randomUUID();
    const [project] = await db
      .insert(projectsTable)
      .values({ id, name: body.name, description: body.description ?? null })
      .returning();

    await db.insert(activityTable).values({
      id: randomUUID(),
      type: "analysis_complete",
      title: "Project created",
      description: `Project "${body.name}" was created`,
      projectId: id,
    });

    res.status(201).json(project);
  } catch (err) {
    req.log.error({ err }, "createProject failed");
    res.status(400).json({ error: String(err) });
  }
});

router.get("/projects/:id", async (req, res) => {
  try {
    const [project] = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.id, req.params.id));
    if (!project) return res.status(404).json({ error: "Not found" });
    res.json(project);
  } catch (err) {
    req.log.error({ err }, "getProject failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/projects/:id", async (req, res) => {
  try {
    await db.delete(projectsTable).where(eq(projectsTable.id, req.params.id));
    res.status(204).end();
  } catch (err) {
    req.log.error({ err }, "deleteProject failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
