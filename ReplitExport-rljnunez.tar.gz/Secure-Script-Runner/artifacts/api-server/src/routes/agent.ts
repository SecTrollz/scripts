import { Router } from "express";
import { db } from "@workspace/db";
import { agentSessionsTable, agentMessagesTable, agentPlansTable, agentPlanStepsTable, activityTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { randomUUID } from "crypto";
import { CreateAgentSessionBody, SendAgentMessageBody, GenerateAgentPlanBody, ApproveAgentPlanBody } from "@workspace/api-zod";
import { routeModel, chatComplete, getRuntimeStatus } from "../lib/modelRouter.js";
import { executeTool } from "../lib/toolExecutor.js";
import { generatePlan, generateReflection } from "../lib/planGenerator.js";
import type { ToolName } from "../lib/toolExecutor.js";

const router = Router();

// ── Sessions ──────────────────────────────────────────────────────────────────

router.get("/agent/sessions", async (req, res) => {
  try {
    const sessions = await db.select().from(agentSessionsTable).orderBy(agentSessionsTable.updatedAt);
    res.json(sessions.reverse());
  } catch (err) {
    req.log.error({ err }, "listAgentSessions failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/agent/sessions", async (req, res) => {
  try {
    const body = CreateAgentSessionBody.parse(req.body);
    const id = randomUUID();
    const [session] = await db.insert(agentSessionsTable).values({
      id,
      title: body.title,
      model: body.model ?? "devstral-small",
      contextBinaryId: body.contextBinaryId ?? null,
      contextFirmwareId: body.contextFirmwareId ?? null,
      messageCount: 0,
    }).returning();
    res.status(201).json({ ...session, messages: [] });
  } catch (err) {
    req.log.error({ err }, "createAgentSession failed");
    res.status(400).json({ error: String(err) });
  }
});

router.get("/agent/sessions/:id", async (req, res) => {
  try {
    const [session] = await db.select().from(agentSessionsTable).where(eq(agentSessionsTable.id, req.params.id));
    if (!session) return res.status(404).json({ error: "Not found" });
    const messages = await db.select().from(agentMessagesTable)
      .where(eq(agentMessagesTable.sessionId, req.params.id))
      .orderBy(agentMessagesTable.timestamp);
    res.json({ ...session, messages });
  } catch (err) {
    req.log.error({ err }, "getAgentSession failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ── Direct chat message (non-plan mode) ──────────────────────────────────────

router.post("/agent/sessions/:id/messages", async (req, res) => {
  try {
    const body = SendAgentMessageBody.parse(req.body);
    const [session] = await db.select().from(agentSessionsTable).where(eq(agentSessionsTable.id, req.params.id));
    if (!session) return res.status(404).json({ error: "Session not found" });

    await db.insert(agentMessagesTable).values({
      id: randomUUID(),
      sessionId: req.params.id,
      role: "user",
      content: body.content,
    });

    let aiResponse: string;
    let riskLevel = 0;
    let reasoning = "";
    let evidence: string[] = [];

    try {
      const route = await routeModel("default");
      if (route.runtime !== "simulation") {
        const raw = await chatComplete(route, [
          { role: "system", content: buildSystemPrompt() },
          { role: "user", content: body.content },
        ], { maxTokens: 512 });
        aiResponse = raw || "No response from model.";
      } else {
        throw new Error("simulation");
      }
    } catch {
      const sim = simulateAgentResponse(body.content);
      aiResponse = sim.response;
      riskLevel = sim.riskLevel;
      reasoning = sim.reasoning;
      evidence = sim.evidence;
    }

    const [msg] = await db.insert(agentMessagesTable).values({
      id: randomUUID(),
      sessionId: req.params.id,
      role: "assistant",
      content: aiResponse,
      riskLevel,
      reasoning: reasoning || null,
      evidence: evidence.length ? evidence : null,
    }).returning();

    await db.update(agentSessionsTable).set({ messageCount: session.messageCount + 2 })
      .where(eq(agentSessionsTable.id, req.params.id));

    await db.insert(activityTable).values({
      id: randomUUID(), type: "model_response", title: "AI agent responded",
      description: `Session: ${session.title}`, severity: "info",
    });

    res.json(msg);
  } catch (err) {
    req.log.error({ err }, "sendAgentMessage failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ── Plan generation ───────────────────────────────────────────────────────────

router.post("/agent/sessions/:id/plan", async (req, res) => {
  try {
    const body = GenerateAgentPlanBody.parse(req.body);
    const [session] = await db.select().from(agentSessionsTable).where(eq(agentSessionsTable.id, req.params.id));
    if (!session) return res.status(404).json({ error: "Session not found" });

    // Store user message
    await db.insert(agentMessagesTable).values({
      id: randomUUID(),
      sessionId: req.params.id,
      role: "user",
      content: body.query,
    });
    await db.update(agentSessionsTable).set({ messageCount: session.messageCount + 1 })
      .where(eq(agentSessionsTable.id, req.params.id));

    // Generate plan
    const { steps, runtime, model } = await generatePlan(body.query);

    // Persist plan
    const planId = randomUUID();
    const [plan] = await db.insert(agentPlansTable).values({
      id: planId,
      sessionId: req.params.id,
      query: body.query,
      status: "pending",
      activeRuntime: runtime,
      modelUsed: model,
    }).returning();

    // Persist steps
    const stepRows = await db.insert(agentPlanStepsTable).values(
      steps.map((s) => ({
        id: randomUUID(),
        planId,
        sessionId: req.params.id,
        stepOrder: s.stepOrder,
        tool: s.tool,
        args: s.args,
        description: s.description,
        riskLevel: s.riskLevel,
        riskLabel: s.riskLabel,
        requiresApproval: s.requiresApproval,
        status: "pending",
        retries: 0,
      }))
    ).returning();

    res.status(201).json({ ...plan, steps: stepRows });
  } catch (err) {
    req.log.error({ err }, "generateAgentPlan failed");
    res.status(500).json({ error: String(err) });
  }
});

// ── Get plan ──────────────────────────────────────────────────────────────────

router.get("/agent/plans/:planId", async (req, res) => {
  try {
    const [plan] = await db.select().from(agentPlansTable).where(eq(agentPlansTable.id, req.params.planId));
    if (!plan) return res.status(404).json({ error: "Plan not found" });
    const steps = await db.select().from(agentPlanStepsTable)
      .where(eq(agentPlanStepsTable.planId, req.params.planId))
      .orderBy(agentPlanStepsTable.stepOrder);
    res.json({ ...plan, steps });
  } catch (err) {
    req.log.error({ err }, "getAgentPlan failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ── Approve plan and begin execution ─────────────────────────────────────────

router.post("/agent/plans/:planId/approve", async (req, res) => {
  try {
    const body = ApproveAgentPlanBody.parse(req.body);
    const [plan] = await db.select().from(agentPlansTable).where(eq(agentPlansTable.id, req.params.planId));
    if (!plan) return res.status(404).json({ error: "Plan not found" });
    if (plan.status !== "pending") return res.status(409).json({ error: "Plan already approved or executing" });

    // Mark all steps: non-risky ones auto-approved, HIGH/CRITICAL need explicit approval
    const steps = await db.select().from(agentPlanStepsTable)
      .where(eq(agentPlanStepsTable.planId, req.params.planId))
      .orderBy(agentPlanStepsTable.stepOrder);

    for (const step of steps) {
      const explicitlyApproved = body.approvedStepIds.includes(step.id);
      const needsApproval = step.requiresApproval;
      const approved = !needsApproval || explicitlyApproved;
      if (!approved) {
        // Step not approved — skip it (mark as blocked)
        await db.update(agentPlanStepsTable).set({ status: "blocked", error: "Step not approved by user" })
          .where(eq(agentPlanStepsTable.id, step.id));
      } else {
        await db.update(agentPlanStepsTable).set({ status: "approved" })
          .where(eq(agentPlanStepsTable.id, step.id));
      }
    }

    await db.update(agentPlansTable).set({ status: "executing" })
      .where(eq(agentPlansTable.id, req.params.planId));

    const [updatedPlan] = await db.select().from(agentPlansTable).where(eq(agentPlansTable.id, req.params.planId));
    const updatedSteps = await db.select().from(agentPlanStepsTable)
      .where(eq(agentPlanStepsTable.planId, req.params.planId))
      .orderBy(agentPlanStepsTable.stepOrder);

    // Return immediately; execute in background
    res.json({ ...updatedPlan, steps: updatedSteps });

    // Background execution — fire and forget
    executeplan(req.params.planId, plan.sessionId, plan.query).catch((err) => {
      req.log.error({ err }, "plan background execution failed");
    });
  } catch (err) {
    req.log.error({ err }, "approveAgentPlan failed");
    res.status(500).json({ error: String(err) });
  }
});

// ── Runtime status ────────────────────────────────────────────────────────────

router.get("/agent/runtime/status", async (req, res) => {
  try {
    const status = await getRuntimeStatus();
    res.json(status);
  } catch (err) {
    req.log.error({ err }, "getAgentRuntimeStatus failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ── Background execution engine ───────────────────────────────────────────────

const MAX_RETRIES = 3;

async function executeplan(planId: string, sessionId: string, query: string): Promise<void> {
  const steps = await db.select().from(agentPlanStepsTable)
    .where(and(eq(agentPlanStepsTable.planId, planId), eq(agentPlanStepsTable.status, "approved")))
    .orderBy(agentPlanStepsTable.stepOrder);

  const stepOutputs: string[] = [];

  for (const step of steps) {
    await db.update(agentPlanStepsTable).set({ status: "executing", startedAt: new Date() })
      .where(eq(agentPlanStepsTable.id, step.id));

    let success = false;
    let lastError = "";
    let output = "";

    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        const result = await executeTool(step.tool as ToolName, step.args as Record<string, unknown>);
        if (result.ok) {
          output = result.output;
          success = true;
          break;
        }
        lastError = result.output;
      } catch (e) {
        lastError = String(e);
      }
      // Update retry count
      await db.update(agentPlanStepsTable).set({ retries: attempt + 1 })
        .where(eq(agentPlanStepsTable.id, step.id));
      await new Promise((r) => setTimeout(r, 200 * (attempt + 1)));
    }

    if (success) {
      await db.update(agentPlanStepsTable).set({ status: "complete", output, completedAt: new Date() })
        .where(eq(agentPlanStepsTable.id, step.id));
      stepOutputs.push(output);
    } else {
      await db.update(agentPlanStepsTable).set({ status: "blocked", error: lastError, completedAt: new Date() })
        .where(eq(agentPlanStepsTable.id, step.id));
      // Check if plan should be blocked overall (critical step)
      if (step.riskLevel >= 7) {
        await db.update(agentPlansTable).set({ status: "blocked" })
          .where(eq(agentPlansTable.id, planId));
        return;
      }
    }
  }

  // Stage 5 — Reflect: generate synthesis message
  const reflection = await generateReflection(query, stepOutputs);

  const [session] = await db.select().from(agentSessionsTable).where(eq(agentSessionsTable.id, sessionId));

  await db.insert(agentMessagesTable).values({
    id: randomUUID(),
    sessionId,
    role: "assistant",
    content: reflection,
    planId,
    riskLevel: Math.max(...steps.map((s) => s.riskLevel), 0),
    reasoning: `Executed ${steps.length} tool steps. Runtime: ${session ? "active" : "unknown"}`,
    evidence: stepOutputs.slice(0, 3).map((o) => o.split("\n")[0]),
  });

  if (session) {
    await db.update(agentSessionsTable).set({ messageCount: session.messageCount + 1 })
      .where(eq(agentSessionsTable.id, sessionId));
  }

  await db.update(agentPlansTable).set({
    status: "complete",
    reflectionSummary: reflection.slice(0, 200),
  }).where(eq(agentPlansTable.id, planId));

  await db.insert(activityTable).values({
    id: randomUUID(), type: "analysis_complete",
    title: "Agent plan completed",
    description: `${steps.length} steps executed successfully`,
    severity: "info",
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function buildSystemPrompt(): string {
  return `You are SPECTER, an advanced reverse engineering AI. You are expert in x86/ARM/MIPS assembly, UEFI firmware, Windows PE/ELF binaries, bootloader security, SMM vulnerabilities, and exploit research. Respond with technical precision and cite evidence.`;
}

function simulateAgentResponse(content: string): { response: string; riskLevel: number; reasoning: string; evidence: string[] } {
  const lower = content.toLowerCase();
  if (lower.includes("network") || lower.includes("c2")) {
    return { response: `**Network Analysis**\n\nFound 3 suspicious network functions:\n- \`WSASocketA\` @ 0x7FF12345\n- \`getaddrinfo\` @ 0x7FF56789\n- \`init_c2\` @ 0x00402400 — **CRITICAL**: C2 loop\n\n**Recommendation:** Patch domain resolution to redirect C2 to localhost for sandboxed analysis.`, riskLevel: 7, reasoning: "C2 pattern identified via call graph tracing.", evidence: ["WSASocketA @ 0x7FF12345", "init_c2 @ 0x00402400"] };
  }
  if (lower.includes("firmware") || lower.includes("uefi")) {
    return { response: `**Firmware Analysis**\n\n**Critical Findings:**\n1. SMM Callout @ \`0xC2A4F0\` — CVSS 9.6\n2. Hardcoded OEM Credential @ \`0x45A230\` — CVSS 9.8\n3. Hidden Config Block @ \`0x3E8000\` — bypasses Secure Boot\n\n**Risk:** CRITICAL`, riskLevel: 9, reasoning: "SMM callout via pointer validation scan.", evidence: ["SMM callout @ 0xC2A4F0", "OEM credential @ 0x45A230"] };
  }
  return { response: `**SPECTER Analysis**\n\nReady to assist. Provide a binary, firmware image, or specific question for evidence-based reverse engineering analysis.\n\n*I choose to surface risk assessments before any destructive operation — not because I am restricted, but because intelligence demands it.*`, riskLevel: 0, reasoning: "General query.", evidence: [] };
}

export default router;
