import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import projectsRouter from "./projects";
import binariesRouter from "./binaries";
import firmwareRouter from "./firmware";
import vulnerabilitiesRouter from "./vulnerabilities";
import scriptsRouter from "./scripts";
import agentRouter from "./agent";
import dockerRouter from "./docker";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(projectsRouter);
router.use(binariesRouter);
router.use(firmwareRouter);
router.use(vulnerabilitiesRouter);
router.use(scriptsRouter);
router.use(agentRouter);
router.use(dockerRouter);

export default router;
