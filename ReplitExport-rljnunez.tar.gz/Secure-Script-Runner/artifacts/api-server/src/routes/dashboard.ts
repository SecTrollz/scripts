import { Router } from "express";
import { db } from "@workspace/db";
import {
  projectsTable,
  binariesTable,
  firmwareTable,
  vulnerabilitiesTable,
  jobsTable,
  activityTable,
} from "@workspace/db";
import { eq, count, and } from "drizzle-orm";

const router = Router();

router.get("/dashboard/stats", async (req, res) => {
  try {
    const [[{ total: totalProjects }], [{ total: totalBinaries }], [{ total: totalFirmware }], [{ total: totalVulnerabilities }], [{ total: criticalVulnerabilities }], [{ total: activeJobs }]] = await Promise.all([
      db.select({ total: count() }).from(projectsTable),
      db.select({ total: count() }).from(binariesTable),
      db.select({ total: count() }).from(firmwareTable),
      db.select({ total: count() }).from(vulnerabilitiesTable),
      db.select({ total: count() }).from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.severity, "critical")),
      db.select({ total: count() }).from(jobsTable).where(eq(jobsTable.status, "running")),
    ]);

    let ollamaOnline = false;
    let ghidraMcpOnline = false;
    let modelName = "devstral-small";

    try {
      const r = await fetch("http://localhost:11434/api/tags", { signal: AbortSignal.timeout(2000) });
      if (r.ok) {
        ollamaOnline = true;
        const data = await r.json() as { models?: Array<{ name: string }> };
        if (data.models?.length) modelName = data.models[0].name;
      }
    } catch {}

    try {
      const r = await fetch("http://localhost:9090/health", { signal: AbortSignal.timeout(2000) });
      if (r.ok) ghidraMcpOnline = true;
    } catch {}

    res.json({
      totalProjects: Number(totalProjects),
      totalBinaries: Number(totalBinaries),
      totalFirmware: Number(totalFirmware),
      totalVulnerabilities: Number(totalVulnerabilities),
      criticalVulnerabilities: Number(criticalVulnerabilities),
      activeJobs: Number(activeJobs),
      ollamaOnline,
      ghidraMcpOnline,
      modelName,
    });
  } catch (err) {
    req.log.error({ err }, "getDashboardStats failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/dashboard/activity", async (req, res) => {
  try {
    const items = await db
      .select()
      .from(activityTable)
      .orderBy(activityTable.timestamp)
      .limit(20);

    res.json(items.reverse().map((a) => ({
      id: a.id,
      type: a.type,
      title: a.title,
      description: a.description,
      severity: a.severity,
      timestamp: a.timestamp,
      projectId: a.projectId,
    })));
  } catch (err) {
    req.log.error({ err }, "getRecentActivity failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
