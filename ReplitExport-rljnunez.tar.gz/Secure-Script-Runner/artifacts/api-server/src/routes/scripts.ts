import { Router } from "express";
import { db } from "@workspace/db";
import { scriptsTable, jobsTable, activityTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { randomUUID } from "crypto";
import { CreateScriptBody, UpdateScriptBody, RunScriptBody } from "@workspace/api-zod";

const router = Router();

router.get("/scripts", async (req, res) => {
  try {
    const rows = await db.select().from(scriptsTable).orderBy(scriptsTable.createdAt);
    res.json(rows.reverse());
  } catch (err) {
    req.log.error({ err }, "listScripts failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/scripts", async (req, res) => {
  try {
    const body = CreateScriptBody.parse(req.body);
    const id = randomUUID();
    const [script] = await db.insert(scriptsTable).values({ id, ...body }).returning();
    res.status(201).json(script);
  } catch (err) {
    req.log.error({ err }, "createScript failed");
    res.status(400).json({ error: String(err) });
  }
});

router.get("/scripts/:id", async (req, res) => {
  try {
    const [script] = await db.select().from(scriptsTable).where(eq(scriptsTable.id, req.params.id));
    if (!script) return res.status(404).json({ error: "Not found" });
    res.json(script);
  } catch (err) {
    req.log.error({ err }, "getScript failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/scripts/:id", async (req, res) => {
  try {
    const body = UpdateScriptBody.parse(req.body);
    const [script] = await db.update(scriptsTable).set(body).where(eq(scriptsTable.id, req.params.id)).returning();
    if (!script) return res.status(404).json({ error: "Not found" });
    res.json(script);
  } catch (err) {
    req.log.error({ err }, "updateScript failed");
    res.status(400).json({ error: String(err) });
  }
});

router.delete("/scripts/:id", async (req, res) => {
  try {
    await db.delete(scriptsTable).where(eq(scriptsTable.id, req.params.id));
    res.status(204).end();
  } catch (err) {
    req.log.error({ err }, "deleteScript failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/scripts/:id/run", async (req, res) => {
  try {
    const body = RunScriptBody.parse(req.body);
    const [script] = await db.select().from(scriptsTable).where(eq(scriptsTable.id, req.params.id));
    if (!script) return res.status(404).json({ error: "Script not found" });

    const jobId = randomUUID();
    const [job] = await db.insert(jobsTable).values({
      id: jobId,
      type: "script_run",
      status: "queued",
      targetId: body.binaryId,
      progress: 0,
      message: `Script "${script.name}" queued`,
      startedAt: new Date(),
    }).returning();

    await db.update(scriptsTable).set({ runCount: script.runCount + 1, lastRunAt: new Date() }).where(eq(scriptsTable.id, req.params.id));

    simulateScriptRun(jobId, script.name).catch(() => {});

    res.status(202).json(job);
  } catch (err) {
    req.log.error({ err }, "runScript failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

async function simulateScriptRun(jobId: string, name: string) {
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  await sleep(300);
  await db.update(jobsTable).set({ status: "running", progress: 20, message: `Executing ${name}...` }).where(eq(jobsTable.id, jobId));
  await sleep(1500);
  await db.update(jobsTable).set({ progress: 70, message: "Processing output..." }).where(eq(jobsTable.id, jobId));
  await sleep(1000);
  await db.update(jobsTable).set({ status: "complete", progress: 100, message: "Script completed", completedAt: new Date() }).where(eq(jobsTable.id, jobId));
  await db.insert(activityTable).values({ id: randomUUID(), type: "script_run", title: "Script executed", description: `Script "${name}" completed successfully`, severity: "info" });
}

export default router;
