import { Router } from "express";
import { db } from "@workspace/db";
import { vulnerabilitiesTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";

const router = Router();

router.get("/vulnerabilities", async (req, res) => {
  try {
    const { binaryId, severity, firmwareId } = req.query;
    let rows = await db.select().from(vulnerabilitiesTable).orderBy(vulnerabilitiesTable.discoveredAt);

    if (binaryId) rows = rows.filter((r) => r.binaryId === String(binaryId));
    if (firmwareId) rows = rows.filter((r) => r.firmwareId === String(firmwareId));
    if (severity) rows = rows.filter((r) => r.severity === String(severity));

    res.json(rows.reverse());
  } catch (err) {
    req.log.error({ err }, "listVulnerabilities failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/vulnerabilities/stats", async (req, res) => {
  try {
    const all = await db.select().from(vulnerabilitiesTable);
    const tally = { critical: 0, high: 0, medium: 0, low: 0, info: 0, patchable: 0, total: all.length };
    for (const v of all) {
      const sev = v.severity as keyof typeof tally;
      if (sev in tally) (tally as Record<string, number>)[sev]++;
      if (v.isPatchable) tally.patchable++;
    }
    res.json(tally);
  } catch (err) {
    req.log.error({ err }, "getVulnerabilityStats failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/vulnerabilities/:id", async (req, res) => {
  try {
    const [vuln] = await db.select().from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.id, req.params.id));
    if (!vuln) return res.status(404).json({ error: "Not found" });
    res.json(vuln);
  } catch (err) {
    req.log.error({ err }, "getVulnerability failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
