# SPECTER — Reverse Engineering Platform

## Architecture

Full-stack reverse engineering platform. **pnpm monorepo** with three workspace packages:

### Artifacts
- **`artifacts/specter`** — React+Vite frontend (port 21359, preview path `/`)
- **`artifacts/api-server`** — Express 5 backend (port 8080, routes at `/api`)

### Libraries
- **`lib/api-spec`** — OpenAPI spec + orval codegen config
- **`lib/api-client-react`** — Generated React Query hooks (from openapi.yaml)
- **`lib/api-zod`** — Generated Zod validators for backend route validation
- **`lib/db`** — Drizzle ORM PostgreSQL client + full schema

## Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Wouter, TanStack Query, shadcn/ui, Tailwind v4, Framer Motion, Recharts |
| Backend | Express 5, Node 20, esbuild bundled |
| Database | PostgreSQL via Drizzle ORM |
| API Contract | OpenAPI 3.0 → orval codegen |
| AI | Ollama local inference (devstral-small recommended) |
| Binary Analysis | Ghidra headless (via Docker MCP) |
| Styling | Dark terminal aesthetic — HSL 145° green on near-black |

## Features

1. **Dashboard** — Live stats, AI engine status, activity feed, analysis chart
2. **Projects** — CRUD project management with binary/firmware/vuln counts
3. **Binary Analysis** — File upload drag-drop, Ghidra headless analysis simulation, function table (risk scores, tags), strings table, job progress
4. **Firmware Analysis** — UEFI/BIOS/embedded analysis, section viewer (entropy, flags, offsets), vulnerability detection
5. **Firmware Patching** — Intelligent risk reasoning, dual consent gates, AI reasoning display, backup/warning system — "dangerous but intelligent"
6. **Vulnerability Scanner** — Severity distribution pie chart, CVE correlation, filterable list, expandable detail with remediation
7. **Ghidra Script Editor** — Monaco-like textarea editor, Python/Java/JS, built-in templates (crypto, network, strings), run via headless Ghidra
8. **AI Agent** — Full Plan→Approve→Execute→Test→Reflect agentic loop. Plan Mode generates structured multi-step tool plans; each HIGH/CRITICAL step requires explicit checkbox approval before execution. RuntimeChip shows active inference engine (vLLM→Ollama→Simulation). Ask Mode for direct chat. Real NVD CVE lookups, all 10 tools with structured simulation output.
9. **Docker Stack Manager** — Container health, CPU/RAM per container, Ollama model catalog with pull buttons, docker-compose.yml template

## Database Schema (Drizzle)

Tables: `projects`, `binaries`, `firmware`, `firmware_sections`, `vulnerabilities`, `scripts`, `agent_sessions`, `agent_messages`, `agent_plans`, `agent_plan_steps`, `jobs`, `activity`

Push schema: `pnpm --filter @workspace/db run push`

## API Routes

All routes served under `/api`:
- `GET/POST /projects`, `GET/DELETE /projects/:id`
- `GET /binaries`, `GET/DELETE /binaries/:id`, `POST /binaries/:id/analyze`
- `GET /binaries/:id/functions`, `GET /binaries/:id/strings`
- `GET /jobs/:id`
- `GET /firmware`, `GET/DELETE /firmware/:id`, `POST /firmware/:id/analyze`, `POST /firmware/:id/patch`
- `GET /firmware/:id/sections`
- `GET /vulnerabilities`, `GET /vulnerabilities/stats`, `GET /vulnerabilities/:id`
- `GET/POST/PUT/DELETE /scripts`, `POST /scripts/:id/run`
- `GET/POST /agent/sessions`, `GET /agent/sessions/:id`, `POST /agent/sessions/:id/messages`
- `GET /docker/status`, `POST /docker/start`, `POST /docker/stop`
- `GET /docker/models`, `POST /docker/models/pull`

## Codegen

```bash
pnpm --filter @workspace/api-spec run codegen
```

Generates:
- `lib/api-client-react/src/generated/api.ts` — React Query hooks
- `lib/api-zod/src/generated/api.ts` — Zod validators

## Docker Stack (for production use)

Requires running:
- **Ghidra MCP server** on `localhost:9090`
- **Ollama** on `localhost:11434` with `devstral-small` or `codestral:22b-q4_K_M` model

See Stack Manager page for `docker-compose.yml` template.

## Design Philosophy

"Dangerous but intelligent" — the platform is capable of destructive operations (firmware patching, binary modification) but applies:
1. AI risk reasoning before any destructive action
2. Dual explicit consent gates (UI checkboxes)
3. Mandatory backup creation
4. Evidence-based explanations for all assessments

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned)
- `SESSION_SECRET` — Express session secret
- `PORT` — Service port (auto-set per artifact by workflow)
