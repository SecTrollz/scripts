import { pgTable, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const firmwareTable = pgTable("firmware", {
  id: text("id").primaryKey(),
  projectId: text("project_id"),
  filename: text("filename").notNull(),
  fileSize: integer("file_size").notNull(),
  firmwareType: text("firmware_type").notNull().default("unknown"),
  vendor: text("vendor"),
  model: text("model"),
  version: text("version"),
  md5: text("md5"),
  sha256: text("sha256"),
  analysisStatus: text("analysis_status").notNull().default("pending"),
  sectionCount: integer("section_count").notNull().default(0),
  vulnerabilityCount: integer("vulnerability_count").notNull().default(0),
  riskLevel: text("risk_level").notNull().default("unknown"),
  uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFirmwareSchema = createInsertSchema(firmwareTable).omit({ uploadedAt: true });
export type InsertFirmware = z.infer<typeof insertFirmwareSchema>;
export type Firmware = typeof firmwareTable.$inferSelect;

export const firmwareSectionsTable = pgTable("firmware_sections", {
  id: text("id").primaryKey(),
  firmwareId: text("firmware_id").notNull(),
  name: text("name").notNull(),
  sectionType: text("section_type").notNull(),
  offset: integer("offset").notNull(),
  size: integer("size").notNull(),
  entropy: real("entropy"),
  description: text("description"),
  flags: text("flags").array(),
});

export const insertFirmwareSectionSchema = createInsertSchema(firmwareSectionsTable);
export type InsertFirmwareSection = z.infer<typeof insertFirmwareSectionSchema>;
export type FirmwareSection = typeof firmwareSectionsTable.$inferSelect;
