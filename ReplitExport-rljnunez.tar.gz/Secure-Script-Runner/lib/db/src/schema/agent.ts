import { pgTable, text, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const agentSessionsTable = pgTable("agent_sessions", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  model: text("model").notNull().default("devstral-small"),
  contextBinaryId: text("context_binary_id"),
  contextFirmwareId: text("context_firmware_id"),
  messageCount: integer("message_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAgentSessionSchema = createInsertSchema(agentSessionsTable).omit({ createdAt: true, updatedAt: true });
export type InsertAgentSession = z.infer<typeof insertAgentSessionSchema>;
export type AgentSession = typeof agentSessionsTable.$inferSelect;

export const agentMessagesTable = pgTable("agent_messages", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  toolCalls: jsonb("tool_calls"),
  riskLevel: integer("risk_level"),
  reasoning: text("reasoning"),
  evidence: text("evidence").array(),
  planId: text("plan_id"),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAgentMessageSchema = createInsertSchema(agentMessagesTable).omit({ timestamp: true });
export type InsertAgentMessage = z.infer<typeof insertAgentMessageSchema>;
export type AgentMessage = typeof agentMessagesTable.$inferSelect;

// ── Agent Plans ──────────────────────────────────────────────────────────────

export const agentPlansTable = pgTable("agent_plans", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  query: text("query").notNull(),
  status: text("status").notNull().default("pending"), // pending | approved | executing | complete | blocked
  activeRuntime: text("active_runtime"), // vllm | ollama | simulation
  modelUsed: text("model_used"),
  reflectionSummary: text("reflection_summary"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAgentPlanSchema = createInsertSchema(agentPlansTable).omit({ createdAt: true, updatedAt: true });
export type InsertAgentPlan = z.infer<typeof insertAgentPlanSchema>;
export type AgentPlan = typeof agentPlansTable.$inferSelect;

export const agentPlanStepsTable = pgTable("agent_plan_steps", {
  id: text("id").primaryKey(),
  planId: text("plan_id").notNull(),
  sessionId: text("session_id").notNull(),
  stepOrder: integer("step_order").notNull(),
  tool: text("tool").notNull(),
  args: jsonb("args").notNull().default({}),
  description: text("description").notNull(),
  riskLevel: integer("risk_level").notNull().default(0), // 0-10
  riskLabel: text("risk_label").notNull().default("low"), // low|medium|high|critical
  requiresApproval: boolean("requires_approval").notNull().default(false),
  status: text("status").notNull().default("pending"), // pending|approved|executing|complete|failed|blocked
  output: text("output"),
  error: text("error"),
  retries: integer("retries").notNull().default(0),
  startedAt: timestamp("started_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const insertAgentPlanStepSchema = createInsertSchema(agentPlanStepsTable).omit({ startedAt: true, completedAt: true });
export type InsertAgentPlanStep = z.infer<typeof insertAgentPlanStepSchema>;
export type AgentPlanStep = typeof agentPlanStepsTable.$inferSelect;
