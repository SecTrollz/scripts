import { pgTable, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const binariesTable = pgTable("binaries", {
  id: text("id").primaryKey(),
  projectId: text("project_id"),
  filename: text("filename").notNull(),
  fileSize: integer("file_size").notNull(),
  fileType: text("file_type"),
  architecture: text("architecture"),
  md5: text("md5"),
  sha256: text("sha256"),
  analysisStatus: text("analysis_status").notNull().default("pending"),
  functionCount: integer("function_count").notNull().default(0),
  stringCount: integer("string_count").notNull().default(0),
  importCount: integer("import_count").notNull().default(0),
  entropyScore: real("entropy_score"),
  uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
  analyzedAt: timestamp("analyzed_at", { withTimezone: true }),
});

export const insertBinarySchema = createInsertSchema(binariesTable).omit({ uploadedAt: true });
export type InsertBinary = z.infer<typeof insertBinarySchema>;
export type Binary = typeof binariesTable.$inferSelect;
