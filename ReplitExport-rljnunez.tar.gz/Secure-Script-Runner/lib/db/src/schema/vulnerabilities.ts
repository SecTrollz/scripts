import { pgTable, text, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const vulnerabilitiesTable = pgTable("vulnerabilities", {
  id: text("id").primaryKey(),
  projectId: text("project_id"),
  binaryId: text("binary_id"),
  firmwareId: text("firmware_id"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull().default("medium"),
  category: text("category").notNull().default("other"),
  address: text("address"),
  cveId: text("cve_id"),
  remediation: text("remediation"),
  riskScore: real("risk_score"),
  isPatchable: boolean("is_patchable").notNull().default(false),
  discoveredAt: timestamp("discovered_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilitiesTable).omit({ discoveredAt: true });
export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
export type Vulnerability = typeof vulnerabilitiesTable.$inferSelect;
