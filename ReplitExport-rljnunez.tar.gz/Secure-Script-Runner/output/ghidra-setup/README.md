# Windows 11 Dev Environment Setup

A single, self-contained Python script that installs and configures a full
reverse-engineering + local AI coding environment on Windows 11.

## What it installs

| Tool | Version | Purpose |
|------|---------|---------|
| **Git for Windows** | latest | Version control |
| **Eclipse Temurin JDK 21** | 21.x | Required by Ghidra 11.3+ |
| **Ghidra** | 11.3.2 | NSA reverse engineering suite |
| **Ghidra source repo** | HEAD | Local API/scripting reference |
| **Ollama** | latest | Local LLM runtime |
| **Codestral** (via Ollama) | latest | Coding model (~7–14 B, GGUF) |
| **Python venv** | — | Isolated environment at `C:\Tools\pyenvs\hf` |

## Requirements

- **Windows 11** (build 22000 or newer)
- **Python 3.8+** already installed (used to run this script)
- **winget** (App Installer) — comes with Windows 11 by default
- **Administrator** privileges recommended (some winget installs need them)
- Internet access

## Quick start

```powershell
# 1. Open PowerShell as Administrator
# 2. Navigate to the folder containing setup.py
cd path\to\ghidra-setup

# 3. Run the script
python setup.py
```

A log file (`setup.log`) is written in the same directory.

## Options

```
python setup.py --help

  --skip-git       Skip Git installation
  --skip-java      Skip Java JDK 21 installation
  --skip-ghidra    Skip Ghidra download and extraction
  --skip-clone     Skip cloning the Ghidra source repository
  --skip-ollama    Skip Ollama and model setup
  --skip-venv      Skip Python virtual environment setup
  --log-file PATH  Custom log file path (default: setup.log)
```

Example — only install Ghidra (assume Git and Java are already present):

```powershell
python setup.py --skip-git --skip-java --skip-ollama --skip-venv --skip-clone
```

## Security notes

- **SHA-256 verification** — The Ghidra ZIP is hashed before extraction.
  The bundled expected hash is a placeholder; the script will warn you and
  ask for confirmation before continuing. Always verify the hash manually at:
  https://github.com/NationalSecurityAgency/ghidra/releases
- **ZIP path traversal guard** — Every entry in the Ghidra archive is
  inspected for `..` or absolute paths before extraction begins.
- **No credentials stored** — The script never reads, writes, or transmits
  any passwords, tokens, or API keys.
- **winget pinned IDs** — Packages are installed by exact package ID
  (`--id ... -e`) to prevent name-squatting confusion.

## After setup — useful commands

```powershell
# Launch Ghidra
C:\Tools\Ghidra\ghidra_11.3.2_PUBLIC\ghidraRun.bat

# Chat with the coding model
ollama run codestral

# Activate the Python venv
C:\Tools\pyenvs\hf\Scripts\Activate.ps1

# Browse the Ghidra source / scripting API
explorer C:\Tools\ghidra-src
```

## Updating Ghidra SHA-256

Open `setup.py` and replace the `GHIDRA_SHA256` constant with the value
published on the official releases page. The hash is listed under
"Assets" → "ghidra_X.Y.Z_PUBLIC_DATE.zip.sha256" on GitHub.

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `winget` not found | Install "App Installer" from the Microsoft Store |
| `java` not on PATH after install | Close & reopen PowerShell, re-run `python setup.py` |
| Ghidra fails to launch | Ensure Java 21+ is first on PATH (`where java`) |
| `ollama pull` hangs | Start Ollama manually: `ollama serve`, then `ollama pull codestral` |
| Need larger/different model | Run `ollama pull qwen2.5-coder:7b` or any other GGUF-compatible model |

## No external dependencies

This script uses only Python's standard library (`argparse`, `hashlib`,
`logging`, `os`, `pathlib`, `platform`, `shutil`, `subprocess`,
`tempfile`, `urllib.request`, `zipfile`). No `pip install` is needed to
run `setup.py` itself.
