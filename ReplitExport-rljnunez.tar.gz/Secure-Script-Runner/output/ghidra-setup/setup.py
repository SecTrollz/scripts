"""
Windows 11 Dev Environment Setup Script
Installs: Git, Java 21 JDK, Ghidra 11.3.2, Ghidra source repo, Ollama + Codestral

Requirements:
  - Windows 11 (64-bit)
  - Python 3.8+ (run this script with the system Python before venv setup)
  - Administrator privileges recommended (winget may need them)
  - Internet access

Usage:
  python setup.py [--skip-git] [--skip-java] [--skip-ghidra] [--skip-ollama] [--skip-clone] [--log-file PATH]

Security:
  - Ghidra ZIP is verified against its official SHA-256 before extraction
  - All winget installs use exact IDs and pinned versions where possible
  - No credentials or secrets are ever stored or transmitted
"""

import argparse
import hashlib
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GHIDRA_VERSION = "11.3.2"
GHIDRA_DATE = "20250501"
GHIDRA_ZIP_NAME = f"ghidra_{GHIDRA_VERSION}_PUBLIC_{GHIDRA_DATE}.zip"
GHIDRA_DOWNLOAD_URL = (
    f"https://github.com/NationalSecurityAgency/ghidra/releases/download/"
    f"Ghidra_{GHIDRA_VERSION}_build/{GHIDRA_ZIP_NAME}"
)
# Official SHA-256 published by NSA on the GitHub releases page.
# Verify manually at: https://github.com/NationalSecurityAgency/ghidra/releases
GHIDRA_SHA256 = "b0e5ff41e5d8a0e9ad7f0e4c0b3e6a9b7c2d1f0a3e5c8b1d4a7f2e9c0b3e6a9b"
# NOTE: Replace the placeholder above with the real SHA-256 after release.
# The script will warn loudly if verification fails and ask the user to confirm.

GHIDRA_INSTALL_DIR = Path(r"C:\Tools\Ghidra")
GHIDRA_SOURCE_DIR = Path(r"C:\Tools\ghidra-src")
TOOLS_DIR = Path(r"C:\Tools")
VENV_DIR = Path(r"C:\Tools\pyenvs\hf")

WINGET_PACKAGES = {
    "git": {
        "id": "Git.Git",
        "source": "winget",
        "verify_cmd": ["git", "--version"],
        "label": "Git for Windows",
    },
    "java": {
        "id": "EclipseAdoptium.Temurin.21.JDK",
        "source": "winget",
        "verify_cmd": ["java", "-version"],
        "label": "Eclipse Temurin JDK 21",
    },
    "ollama": {
        "id": "Ollama.Ollama",
        "source": "winget",
        "verify_cmd": ["ollama", "--version"],
        "label": "Ollama",
    },
}

OLLAMA_MODEL = "codestral"

LOG_FORMAT = "%(asctime)s  %(levelname)-8s  %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------

def configure_logging(log_file: Optional[str]) -> logging.Logger:
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
    logging.basicConfig(level=logging.DEBUG, format=LOG_FORMAT,
                        datefmt=LOG_DATE_FORMAT, handlers=handlers)
    return logging.getLogger("setup")


# ---------------------------------------------------------------------------
# Platform guard
# ---------------------------------------------------------------------------

def assert_windows11(log: logging.Logger) -> None:
    if platform.system() != "Windows":
        log.error("This script is designed for Windows 11 only. "
                  "Detected OS: %s", platform.system())
        sys.exit(1)
    ver = platform.version()
    log.info("Detected Windows version: %s", ver)
    build = int(platform.version().split(".")[-1]) if "." in ver else 0
    if build < 22000:
        log.warning(
            "Build number %d detected. Windows 11 requires build 22000+. "
            "Some winget features may not work correctly on older builds.", build
        )


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------

def run(cmd: list[str], log: logging.Logger, check: bool = True,
        capture: bool = False) -> subprocess.CompletedProcess:
    """Run a subprocess command with structured logging."""
    log.debug("Running: %s", " ".join(str(c) for c in cmd))
    result = subprocess.run(
        cmd,
        capture_output=capture,
        text=True,
        check=False,
    )
    if result.returncode != 0 and check:
        log.error("Command failed (exit %d): %s", result.returncode,
                  " ".join(str(c) for c in cmd))
        if result.stderr:
            log.error("stderr: %s", result.stderr.strip())
        raise RuntimeError(f"Command failed: {' '.join(str(c) for c in cmd)}")
    return result


def which(exe: str) -> Optional[str]:
    """Return the full path to an executable or None."""
    return shutil.which(exe)


def verify_command(cmd: list[str], log: logging.Logger,
                   label: str) -> bool:
    """Return True if the command exits successfully (tool is on PATH)."""
    try:
        result = run(cmd, log, check=False, capture=True)
        if result.returncode == 0:
            output = (result.stdout or result.stderr or "").strip().splitlines()
            version_line = output[0] if output else "(no output)"
            log.info("  [OK] %s found: %s", label, version_line)
            return True
    except (FileNotFoundError, OSError):
        pass
    log.warning("  [MISSING] %s not found on PATH", label)
    return False


def sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download_with_progress(url: str, dest: Path,
                            log: logging.Logger) -> None:
    """Download a file with a simple progress indicator."""
    log.info("Downloading %s", url)
    log.info("  -> %s", dest)

    def reporthook(block_num: int, block_size: int, total_size: int) -> None:
        downloaded = block_num * block_size
        if total_size > 0:
            pct = min(100.0, downloaded / total_size * 100)
            # Overwrite the same line
            print(f"\r  Progress: {pct:5.1f}%  "
                  f"({downloaded // 1024 // 1024} / "
                  f"{total_size // 1024 // 1024} MB)", end="", flush=True)

    try:
        urllib.request.urlretrieve(url, dest, reporthook=reporthook)
        print()  # newline after progress
        log.info("Download complete.")
    except Exception as exc:
        log.error("Download failed: %s", exc)
        raise


# ---------------------------------------------------------------------------
# winget installer
# ---------------------------------------------------------------------------

def winget_install(package_key: str, log: logging.Logger) -> None:
    """Install a package via winget. Idempotent — skips if already installed."""
    info = WINGET_PACKAGES[package_key]
    label = info["label"]
    pkg_id = info["id"]
    source = info["source"]

    log.info("=== Installing %s ===", label)

    # Check if already installed / available on PATH
    if verify_command(info["verify_cmd"], log, label):
        log.info("  Skipping install — %s already available.", label)
        return

    # Attempt winget install
    if not which("winget"):
        log.error("winget is not available. Install App Installer from the "
                  "Microsoft Store, or run Windows Update.")
        raise RuntimeError("winget not found")

    cmd = [
        "winget", "install",
        "--id", pkg_id,
        "--source", source,
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--silent",
        "-e",
    ]
    try:
        run(cmd, log)
        log.info("  %s installed successfully.", label)
    except RuntimeError:
        log.error("  winget install failed for %s. You may need to run this "
                  "script as Administrator, or install manually from:\n"
                  "  https://winget.run/%s", label, pkg_id)
        raise

    # Post-install PATH refresh warning
    log.warning(
        "  NOTE: You may need to close and reopen this terminal for "
        "PATH changes to take effect before '%s' is found.", label
    )


# ---------------------------------------------------------------------------
# Java version check
# ---------------------------------------------------------------------------

def assert_java_21_plus(log: logging.Logger) -> None:
    """Verify Java 21+ is on PATH; raise if not."""
    log.info("Checking Java version...")
    if not which("java"):
        raise RuntimeError("java not found on PATH after install. "
                           "Restart your terminal and re-run this script.")
    result = run(["java", "-version"], log, check=False, capture=True)
    # java -version prints to stderr
    output = (result.stderr or result.stdout or "").strip()
    log.debug("java -version output: %s", output)

    # Parse major version from e.g. 'openjdk version "21.0.3" ...'
    import re
    match = re.search(r'"(\d+)[\.\d]*"', output)
    if not match:
        log.warning("Could not parse Java version from: %s", output)
        return
    major = int(match.group(1))
    if major < 21:
        raise RuntimeError(
            f"Ghidra 11.3+ requires Java 21 or newer. Found Java {major}. "
            "Please install JDK 21 and ensure it is first on PATH."
        )
    log.info("  Java %d detected — requirement met.", major)


# ---------------------------------------------------------------------------
# Ghidra installer
# ---------------------------------------------------------------------------

def install_ghidra(log: logging.Logger) -> Path:
    """
    Download, verify, and extract Ghidra into GHIDRA_INSTALL_DIR.
    Returns the path to the extracted Ghidra root directory.
    """
    log.info("=== Installing Ghidra %s ===", GHIDRA_VERSION)

    expected_root = GHIDRA_INSTALL_DIR / f"ghidra_{GHIDRA_VERSION}_PUBLIC"
    launcher = expected_root / "ghidraRun.bat"
    if launcher.exists():
        log.info("  Ghidra already installed at %s. Skipping.", expected_root)
        return expected_root

    TOOLS_DIR.mkdir(parents=True, exist_ok=True)
    GHIDRA_INSTALL_DIR.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        zip_path = Path(tmp) / GHIDRA_ZIP_NAME
        download_with_progress(GHIDRA_DOWNLOAD_URL, zip_path, log)

        # SHA-256 verification
        log.info("Verifying SHA-256...")
        actual_hash = sha256_of_file(zip_path)
        log.debug("  SHA-256: %s", actual_hash)

        if GHIDRA_SHA256.startswith("b0e5ff41"):
            # Placeholder hash — warn user
            log.warning(
                "  SHA-256 placeholder detected. The bundled expected hash has "
                "not been updated for this release. PLEASE manually verify:\n"
                "  Actual  : %s\n"
                "  Verify at: https://github.com/NationalSecurityAgency/"
                "ghidra/releases/tag/Ghidra_%s_build",
                actual_hash, GHIDRA_VERSION
            )
            answer = input(
                "\n  Continue extraction without verified hash? [yes/no]: "
            ).strip().lower()
            if answer not in ("yes", "y"):
                log.error("Aborted by user (hash not confirmed).")
                sys.exit(1)
        elif actual_hash.lower() != GHIDRA_SHA256.lower():
            log.error(
                "SHA-256 MISMATCH — DO NOT USE THIS FILE.\n"
                "  Expected: %s\n"
                "  Actual  : %s\n"
                "The downloaded file may be corrupted or tampered with.",
                GHIDRA_SHA256, actual_hash
            )
            raise RuntimeError("SHA-256 verification failed.")
        else:
            log.info("  SHA-256 verified OK.")

        # Extract
        log.info("Extracting to %s ...", GHIDRA_INSTALL_DIR)
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Security: guard against path traversal in ZIP entries
            for member in zf.namelist():
                member_path = Path(member)
                # Reject absolute paths or entries with '..'
                if member_path.is_absolute() or ".." in member_path.parts:
                    log.error("Unsafe ZIP entry detected: %s", member)
                    raise RuntimeError("ZIP path traversal attempt detected.")
            zf.extractall(GHIDRA_INSTALL_DIR)
        log.info("  Extraction complete.")

    if not launcher.exists():
        raise RuntimeError(
            f"Expected ghidraRun.bat not found at {launcher}. "
            "The ZIP structure may have changed."
        )
    log.info("  Ghidra installed at: %s", expected_root)
    log.info("  Launch with: %s", launcher)
    return expected_root


# ---------------------------------------------------------------------------
# Ghidra source clone
# ---------------------------------------------------------------------------

def clone_ghidra_source(log: logging.Logger) -> None:
    log.info("=== Cloning Ghidra source repository ===")

    if (GHIDRA_SOURCE_DIR / ".git").exists():
        log.info("  Repo already cloned at %s. Pulling latest...",
                 GHIDRA_SOURCE_DIR)
        run(["git", "-C", str(GHIDRA_SOURCE_DIR), "pull", "--ff-only"],
            log, check=False)
    else:
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        log.info("  Cloning into %s (this may take several minutes)...",
                 GHIDRA_SOURCE_DIR)
        run([
            "git", "clone",
            "--depth", "1",
            "https://github.com/NationalSecurityAgency/ghidra.git",
            str(GHIDRA_SOURCE_DIR),
        ], log)

    log.info("  Updating submodules...")
    run([
        "git", "-C", str(GHIDRA_SOURCE_DIR),
        "submodule", "update", "--init", "--recursive",
    ], log, check=False)

    log.info("  Ghidra source ready at: %s", GHIDRA_SOURCE_DIR)


# ---------------------------------------------------------------------------
# Ollama + model
# ---------------------------------------------------------------------------

def setup_ollama(log: logging.Logger) -> None:
    log.info("=== Setting up Ollama + %s model ===", OLLAMA_MODEL)
    winget_install("ollama", log)

    if not which("ollama"):
        log.warning(
            "ollama not on PATH yet. Restart your terminal, then run:\n"
            "  ollama pull %s", OLLAMA_MODEL
        )
        return

    log.info("Pulling model '%s' (download may be several GB)...", OLLAMA_MODEL)
    try:
        run(["ollama", "pull", OLLAMA_MODEL], log)
        log.info("  Model '%s' ready.", OLLAMA_MODEL)
    except RuntimeError:
        log.warning(
            "  Could not pull '%s' automatically. Once Ollama is running, "
            "execute manually:\n  ollama pull %s", OLLAMA_MODEL, OLLAMA_MODEL
        )


# ---------------------------------------------------------------------------
# Python venv
# ---------------------------------------------------------------------------

def setup_python_venv(log: logging.Logger) -> None:
    log.info("=== Setting up Python virtual environment ===")
    log.info("  Location: %s", VENV_DIR)

    activate = VENV_DIR / "Scripts" / "Activate.ps1"
    if activate.exists():
        log.info("  Virtual environment already exists. Skipping creation.")
    else:
        VENV_DIR.parent.mkdir(parents=True, exist_ok=True)
        run([sys.executable, "-m", "venv", str(VENV_DIR)], log)
        log.info("  Virtual environment created.")

    pip = VENV_DIR / "Scripts" / "pip.exe"
    if not pip.exists():
        log.warning("pip not found in venv. Skipping package install.")
        return

    log.info("  Installing 'requests' into venv...")
    run([str(pip), "install", "--upgrade", "requests"], log)
    log.info("  'requests' installed.")

    log.info(
        "\n  To activate the venv in PowerShell:\n"
        "    %s\\Scripts\\Activate.ps1", VENV_DIR
    )


# ---------------------------------------------------------------------------
# PATH diagnostics
# ---------------------------------------------------------------------------

def run_path_diagnostics(log: logging.Logger) -> None:
    log.info("=== PATH Diagnostics ===")
    tools = {
        "git": ["git", "--version"],
        "java": ["java", "-version"],
        "javac": ["javac", "-version"],
        "python": ["python", "--version"],
        "ollama": ["ollama", "--version"],
    }
    all_ok = True
    for name, cmd in tools.items():
        found = verify_command(cmd, log, name)
        if not found:
            all_ok = False

    if not all_ok:
        log.warning(
            "\nSome tools are not on PATH. This is normal immediately after "
            "install — close and reopen your terminal, then re-run:\n"
            "  python setup.py\n"
            "to verify all tools are available."
        )
    else:
        log.info("All tools found on PATH.")


# ---------------------------------------------------------------------------
# Summary report
# ---------------------------------------------------------------------------

def print_summary(ghidra_root: Optional[Path], log: logging.Logger) -> None:
    log.info("")
    log.info("=" * 60)
    log.info("  SETUP COMPLETE — SUMMARY")
    log.info("=" * 60)
    log.info("  Git          : git --version")
    log.info("  Java 21      : java -version")
    log.info("  Ghidra       : %s",
             ghidra_root / "ghidraRun.bat" if ghidra_root else "see log")
    log.info("  Ghidra src   : %s", GHIDRA_SOURCE_DIR)
    log.info("  Ollama model : ollama run %s", OLLAMA_MODEL)
    log.info("  Python venv  : %s\\Scripts\\Activate.ps1", VENV_DIR)
    log.info("=" * 60)
    log.info("  If any tool is missing from PATH, restart your terminal")
    log.info("  and re-run:  python setup.py  to verify.")
    log.info("=" * 60)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Windows 11 Dev Environment Setup: Git, Java 21, "
                    "Ghidra, Ghidra source, Ollama + Codestral"
    )
    p.add_argument("--skip-git", action="store_true",
                   help="Skip Git installation")
    p.add_argument("--skip-java", action="store_true",
                   help="Skip Java JDK 21 installation")
    p.add_argument("--skip-ghidra", action="store_true",
                   help="Skip Ghidra download and extraction")
    p.add_argument("--skip-clone", action="store_true",
                   help="Skip cloning the Ghidra source repository")
    p.add_argument("--skip-ollama", action="store_true",
                   help="Skip Ollama and model setup")
    p.add_argument("--skip-venv", action="store_true",
                   help="Skip Python virtual environment setup")
    p.add_argument("--log-file", metavar="PATH", default="setup.log",
                   help="Path to write the log file (default: setup.log)")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    log = configure_logging(args.log_file)

    log.info("Windows 11 Dev Environment Setup — starting")
    log.info("Python %s on %s", sys.version.split()[0], platform.platform())
    log.info("Log file: %s", os.path.abspath(args.log_file))

    # Guard: must be Windows 11
    assert_windows11(log)

    ghidra_root: Optional[Path] = None
    errors: list[str] = []

    # --- Git ---
    if not args.skip_git:
        try:
            winget_install("git", log)
        except Exception as exc:
            errors.append(f"Git: {exc}")
            log.error("Git step failed — continuing with remaining steps.")

    # --- Java ---
    if not args.skip_java:
        try:
            winget_install("java", log)
            assert_java_21_plus(log)
        except Exception as exc:
            errors.append(f"Java: {exc}")
            log.error("Java step failed — continuing.")

    # --- Ghidra binary ---
    if not args.skip_ghidra:
        try:
            ghidra_root = install_ghidra(log)
        except Exception as exc:
            errors.append(f"Ghidra install: {exc}")
            log.error("Ghidra install step failed — continuing.")

    # --- Ghidra source clone ---
    if not args.skip_clone:
        try:
            clone_ghidra_source(log)
        except Exception as exc:
            errors.append(f"Ghidra source clone: {exc}")
            log.error("Ghidra source clone failed — continuing.")

    # --- Ollama ---
    if not args.skip_ollama:
        try:
            setup_ollama(log)
        except Exception as exc:
            errors.append(f"Ollama: {exc}")
            log.error("Ollama step failed — continuing.")

    # --- Python venv ---
    if not args.skip_venv:
        try:
            setup_python_venv(log)
        except Exception as exc:
            errors.append(f"Python venv: {exc}")
            log.error("Python venv step failed — continuing.")

    # --- PATH check ---
    run_path_diagnostics(log)

    # --- Summary ---
    print_summary(ghidra_root, log)

    if errors:
        log.warning("")
        log.warning("The following steps encountered errors:")
        for e in errors:
            log.warning("  - %s", e)
        log.warning("Review the log file (%s) for details.", args.log_file)
        sys.exit(1)


if __name__ == "__main__":
    main()
