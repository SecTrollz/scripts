# 🔒 Privacy Stack — OCI Free Tier
### Traefik · WireGuard VPN · Tor+obfs4 · I2P · DNSCrypt · Authelia 2FA · Browser Isolation

---

## Architecture Overview

```
Internet
   │
   ▼
[OCI Instance — Public IP]
   │
   ├── Port 80  ──► Traefik (redirects to HTTPS)
   ├── Port 443 ──► Traefik (TLS termination, auth enforcement)
   └── Port 51820/UDP ──► WireGuard VPN
         │
         ├── auth.domain.com      ─► Authelia (user+pass+TOTP 2FA)
         ├── traefik.domain.com   ─► Traefik dashboard
         ├── portainer.domain.com ─► Docker management
         ├── vpn.domain.com       ─► WireGuard config download
         ├── firefox.domain.com   ─► Firefox browser (noVNC)
         ├── chrome.domain.com    ─► Chromium browser (noVNC)
         ├── tor.domain.com       ─► Tor SOCKS proxy (obfs4)
         └── i2p.domain.com       ─► I2P router console
```

All services are behind Authelia — **you must authenticate with username + password + TOTP 2FA** to reach anything.

---

## Prerequisites

- OCI Free Tier instance (Ubuntu 22.04, VM.Standard.E2.1.Micro or A1.Flex recommended)
- A domain managed by **Cloudflare DNS** (free tier is fine)
- Cloudflare **DNS API token** (Zone:DNS:Edit permissions only)
- A TOTP app: Google Authenticator, Authy, Bitwarden, etc.
- OCI CloudShell or SSH access

---

## Quick Start

### 1. Upload files to your OCI instance

From OCI CloudShell:
```bash
# SCP the whole folder to your instance
scp -r privacy-stack/ ubuntu@YOUR_OCI_IP:~/

# Then SSH in
ssh ubuntu@YOUR_OCI_IP
cd privacy-stack
```

### 2. Run the setup script
```bash
chmod +x scripts/setup.sh
sudo bash scripts/setup.sh
```

The script will ask you for:
- Your domain
- Cloudflare credentials
- Your username and password
- It auto-generates all secret keys

### 3. Open OCI Security List ports

In OCI Console:
- **Networking → VCN → Security Lists → Ingress Rules**
- Add: TCP 80, TCP 443, UDP 51820

### 4. Enroll 2FA

Visit `https://auth.yourdomain.com`, log in, scan the QR code with your TOTP app.

---

## Services

| Service | URL | Purpose |
|---------|-----|---------|
| Authelia | auth.domain.com | 2FA portal — login here first |
| Traefik | traefik.domain.com | Reverse proxy dashboard |
| Portainer | portainer.domain.com | Docker container management |
| WireGuard | vpn.domain.com | Personal VPN — zero logs |
| Firefox | firefox.domain.com | Isolated Firefox browser |
| Chromium | chrome.domain.com | Isolated Chromium browser |
| Tor | tor.domain.com | Tor proxy with obfs4 |
| I2P | i2p.domain.com | I2P anonymous network |

---

## Browser Setup

### Firefox (container)
- Accessible at `https://firefox.domain.com` after 2FA
- Pre-configured to use DuckDuckGo
- To use Tor: set SOCKS5 proxy → `tor:9050`
- To use I2P: set HTTP proxy → `i2p:4444`

### Chromium (container)
- Accessible at `https://chrome.domain.com` after 2FA
- Same proxy options as Firefox

### Opera / Ecosia / DuckDuckGo on your local device
- Connect to WireGuard VPN first (see vpn.domain.com for config)
- All your traffic routes through your OCI server
- DNS goes through DNSCrypt-proxy (encrypted, no-log)

---

## WireGuard VPN

After setup, your WireGuard config is at `/wireguard_data/peer1/peer1.conf`.

Download it:
```bash
docker exec wireguard cat /config/peer1/peer1.conf
```

Or visit `https://vpn.domain.com` (after 2FA) to download the QR code.

Import into:
- **iOS/Android**: WireGuard app — scan QR
- **Windows/Mac**: WireGuard app — import .conf file
- **Linux**: `wg-quick up peer1`

All traffic including DNS goes through your server → DNSCrypt-proxy → encrypted resolvers.

---

## Tor + obfs4

Get bridges from https://bridges.torproject.org — select **obfs4** type.

Add them to `tor/torrc`:
```
Bridge obfs4 IP:PORT FINGERPRINT cert=XXXXX iat-mode=0
```

Then restart Tor:
```bash
docker compose restart tor
```

obfs4 makes your Tor traffic look like random HTTPS, helping bypass censorship and reduce fingerprinting.

---

## I2P

I2P is an anonymous overlay network (different from Tor). After the router boots (~5-10 min for integration):
- Router console: `https://i2p.domain.com`
- HTTP proxy for .i2p sites: `i2p:4444`
- Useful for: I2P-internal sites (eepsites), anonymous torrents, I2P mail

---

## DNSCrypt

- Runs at `10.10.0.3:53` inside the VPN network
- WireGuard clients automatically use it
- Servers used: Cloudflare, Quad9, Mullvad, AdGuard — all require `nolog` and `dnssec`
- Anonymized DNS routing hides your queries even from the resolver

---

## Security Hardening Included

- ✅ TLS 1.2+ only, strong cipher suites
- ✅ HSTS with preload (1-year)
- ✅ Security headers (CSP, XSS, no-sniff, referrer policy)
- ✅ Authelia 2FA on every service
- ✅ Rate limiting (100 req/s burst 50)
- ✅ Fail2ban (bans after 3 failed attempts, 10 min ban)
- ✅ UFW firewall (deny all, allow only 22/80/443/51820)
- ✅ Argon2id password hashing
- ✅ Secrets never in images — all via env vars
- ✅ Docker socket read-only where possible
- ✅ No new privileges on containers
- ✅ Redis password-protected session store
- ✅ WireGuard: no connection logs (LOG_CONFS=false)
- ✅ DNSCrypt: logs to /dev/null
- ✅ Tor: SafeLogging on

---

## File Structure

```
privacy-stack/
├── docker-compose.yml          # Main stack
├── docker-compose.authelia.yml # Authelia + Redis (merge into main)
├── .env.template               # Copy to .env and fill in
├── traefik/
│   └── config/
│       ├── traefik.yml         # Traefik static config
│       └── dynamic.yml         # Middlewares, TLS options
├── dnscrypt/
│   └── dnscrypt-proxy.toml     # Encrypted DNS config
├── tor/
│   └── torrc                   # Tor + obfs4 config
├── secrets/
│   └── authelia/
│       ├── configuration.yml   # Authelia config
│       └── users_database.yml  # Created by setup.sh
└── scripts/
    └── setup.sh                # Full auto-setup script
```

---

## Updating

```bash
docker compose pull
docker compose up -d
```

---

## OCI Free Tier Notes

- **Always Free**: 2x VM.Standard.E2.1.Micro (1 OCPU, 1GB RAM each) or 1x A1.Flex (4 OCPU, 24GB RAM)
- Recommend: A1.Flex if available — more RAM = better for all services running simultaneously
- Boot volume: 50GB free
- Bandwidth: 10TB/month outbound free
- The A1 ARM instance runs all containers fine — all images support arm64

---

## Troubleshooting

**Traefik not getting certs:**
- Check Cloudflare token has `Zone:DNS:Edit` permission
- Check `.env` CF_EMAIL and CF_DNS_TOKEN are correct
- `docker logs traefik`

**Can't reach services:**
- Check OCI Security List has ports 80, 443 open
- Check `ufw status`
- Check Authelia is running: `docker logs authelia`

**WireGuard not connecting:**
- Check UDP 51820 is open in OCI Security List
- Check `docker logs wireguard`
- Ensure `net.ipv4.ip_forward=1` is set

**Tor not connecting:**
- Add real obfs4 bridges to torrc
- `docker logs tor-obfs4`
- It can take 1-2 min to build circuits on first start
