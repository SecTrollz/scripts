#!/usr/bin/env bash
# ============================================================
# PRIVACY STACK - OCI FREE TIER AUTO-SETUP
# Run from OCI CloudShell against your free-tier instance
# ============================================================
set -euo pipefail

# ── Colors ──
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

banner() {
  echo -e "${CYAN}${BOLD}"
  echo "  ╔══════════════════════════════════════════╗"
  echo "  ║   PRIVACY STACK — OCI FREE TIER SETUP   ║"
  echo "  ║   Traefik | WG | Tor | I2P | DNSCrypt   ║"
  echo "  ╚══════════════════════════════════════════╝"
  echo -e "${NC}"
}

log()  { echo -e "${GREEN}[✔]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✘]${NC} $1"; exit 1; }
ask()  { read -rp "$(echo -e ${CYAN}[?]${NC} $1): " "$2"; }

banner

# ── Preflight: Must be run as root or sudo capable ──
if [[ "$EUID" -ne 0 ]]; then
  warn "Not root — will use sudo"
  SUDO="sudo"
else
  SUDO=""
fi

# ── 1. Gather config ──
echo -e "\n${BOLD}── Step 1: Configuration ──${NC}"
ask "Your public domain (e.g. example.com)" DOMAIN
ask "Cloudflare email" CF_EMAIL
ask "Cloudflare DNS API Token" CF_DNS_TOKEN
ask "Your OCI instance public IP" SERVER_IP
ask "Timezone (e.g. America/New_York)" TZ
ask "WireGuard hostname (usually same as domain or subdomain)" WG_HOST
USERNAME="admin"

# ── 2. Install dependencies on Ubuntu 22.04 ──
echo -e "\n${BOLD}── Step 2: System packages ──${NC}"
$SUDO apt-get update -qq
$SUDO apt-get install -y -qq \
  curl wget git jq openssl \
  docker.io docker-compose-v2 \
  wireguard iptables-persistent \
  fail2ban ufw \
  obfs4proxy tor

log "Packages installed"

# ── 3. Docker setup ──
echo -e "\n${BOLD}── Step 3: Docker ──${NC}"
$SUDO systemctl enable --now docker
$SUDO usermod -aG docker "$USER" || true
$SUDO docker network create proxy 2>/dev/null || warn "proxy network already exists"
log "Docker ready"

# ── 4. OCI firewall rules (iptables + OCI security list reminder) ──
echo -e "\n${BOLD}── Step 4: Firewall hardening ──${NC}"
$SUDO ufw --force reset
$SUDO ufw default deny incoming
$SUDO ufw default allow outgoing
$SUDO ufw allow 22/tcp   comment "SSH"
$SUDO ufw allow 80/tcp   comment "HTTP->HTTPS redirect"
$SUDO ufw allow 443/tcp  comment "HTTPS"
$SUDO ufw allow 51820/udp comment "WireGuard"
$SUDO ufw --force enable
log "UFW configured"

warn "IMPORTANT: Also open ports 80, 443, 51820/udp in your OCI Security List!"
warn "OCI Console → VCN → Security Lists → Ingress Rules"

# ── 5. Generate secrets ──
echo -e "\n${BOLD}── Step 5: Generating secrets ──${NC}"
AUTHELIA_JWT_SECRET=$(openssl rand -hex 32)
AUTHELIA_SESSION_SECRET=$(openssl rand -hex 32)
AUTHELIA_STORAGE_KEY=$(openssl rand -hex 32)
REDIS_PASSWORD=$(openssl rand -hex 24)
log "Secrets generated"

# ── 6. Write .env file ──
echo -e "\n${BOLD}── Step 6: Writing .env ──${NC}"
cat > .env <<EOF
DOMAIN=${DOMAIN}
CF_EMAIL=${CF_EMAIL}
CF_DNS_TOKEN=${CF_DNS_TOKEN}
SERVER_IP=${SERVER_IP}
TZ=${TZ}
WG_HOST=${WG_HOST}
AUTHELIA_JWT_SECRET=${AUTHELIA_JWT_SECRET}
AUTHELIA_SESSION_SECRET=${AUTHELIA_SESSION_SECRET}
AUTHELIA_STORAGE_KEY=${AUTHELIA_STORAGE_KEY}
REDIS_PASSWORD=${REDIS_PASSWORD}
EOF
chmod 600 .env
log ".env written (chmod 600)"

# ── 7. Create Authelia user ──
echo -e "\n${BOLD}── Step 7: Create your user account ──${NC}"
ask "Choose your username" AUTH_USER
echo -n "Choose your password: "
read -rs AUTH_PASS; echo

# Hash password with argon2id
HASHED=$(docker run --rm authelia/authelia:latest \
  authelia crypto hash generate argon2 --password "$AUTH_PASS" 2>/dev/null | grep "Digest:" | awk '{print $2}')

mkdir -p secrets/authelia
cat > secrets/authelia/users_database.yml <<EOF
users:
  ${AUTH_USER}:
    disabled: false
    displayname: "${AUTH_USER}"
    password: "${HASHED}"
    email: ${CF_EMAIL}
    groups:
      - admins
EOF
chmod 600 secrets/authelia/users_database.yml
log "User '${AUTH_USER}' created with argon2id hash"

# ── 8. Tor bridges ──
echo -e "\n${BOLD}── Step 8: Tor obfs4 bridges ──${NC}"
echo -e "${YELLOW}  Get bridges at: https://bridges.torproject.org (choose obfs4)${NC}"
warn "Add your bridge lines to tor/torrc — see the Bridge lines section"

# ── 9. Pull images & start ──
echo -e "\n${BOLD}── Step 9: Pull & start stack ──${NC}"
$SUDO docker compose pull
$SUDO docker compose up -d

log "Stack is starting!"

# ── 10. Post-setup 2FA enrollment ──
echo -e "\n${BOLD}── Step 10: Enroll 2FA ──${NC}"
echo -e "${CYAN}  1. Visit https://auth.${DOMAIN}${NC}"
echo -e "${CYAN}  2. Log in with your username + password${NC}"
echo -e "${CYAN}  3. You will be prompted to scan a QR code with your TOTP app${NC}"
echo -e "${CYAN}     (Google Authenticator, Authy, or any TOTP app)${NC}"
echo -e "${CYAN}  4. After enrolling 2FA you will be able to reach all services${NC}"

echo ""
log "═══════════════════════════════════════"
log " SETUP COMPLETE — YOUR SERVICES:"
log "   https://traefik.${DOMAIN}  — Traefik dashboard"
log "   https://portainer.${DOMAIN} — Container manager"
log "   https://vpn.${DOMAIN}       — WireGuard config"
log "   https://firefox.${DOMAIN}   — Browser (Firefox)"
log "   https://chrome.${DOMAIN}    — Browser (Chromium)"
log "   https://i2p.${DOMAIN}       — I2P router console"
log "   https://tor.${DOMAIN}       — Tor SOCKS proxy"
log "   https://auth.${DOMAIN}      — Authelia 2FA portal"
log "═══════════════════════════════════════"
warn "Store your .env file securely — it contains all secrets"
